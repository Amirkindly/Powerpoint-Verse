pptxgen.bundle.js is downloaded here by setup_android.sh (or at first run by the app).
