#!/usr/bin/env bash
# Run once (locally or in CI) from project root
set -e
flutter create --org com.powerpointverse --project-name powerpoint_verse --platforms android .
rm -rf test
M=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="PowerPoint Verse"/' $M
grep -q 'permission.INTERNET' $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <queries><intent><action android:name="android.speech.RecognitionService"/></intent></queries>\n    <application#' $M
mkdir -p assets/web
curl -L -o assets/web/pptxgen.bundle.js https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js || true
flutter pub get
