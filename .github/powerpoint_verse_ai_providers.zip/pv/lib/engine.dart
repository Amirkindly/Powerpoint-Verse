import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

const _libUrl = 'https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js';

/// Runs PptxGenJS inside a hidden WebView and returns the .pptx bytes.
class PptxEngine {
  late final WebViewController controller;
  final Completer<void> _loaded = Completer<void>();
  Completer<String>? _pending;
  Future<void>? _initFuture;

  PptxEngine() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Pptx', onMessageReceived: (m) {
        final p = _pending;
        if (p != null && !p.isCompleted) p.complete(m.message);
      })
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
        if (!_loaded.isCompleted) _loaded.complete();
      }));
  }

  Future<void> ensureReady() {
    _initFuture ??= _init().catchError((e) {
      _initFuture = null;
      throw e;
    });
    return _initFuture!;
  }

  Future<void> _init() async {
    await controller.loadHtmlString('<html><body></body></html>');
    await _loaded.future.timeout(const Duration(seconds: 20));
    final lib = await _loadLib();
    await controller.runJavaScript(lib);
    await controller.runJavaScript(_glue);
  }

  Future<String> _loadLib() async {
    try {
      final s = await rootBundle.loadString('assets/web/pptxgen.bundle.js');
      if (s.length > 1000) return s;
    } catch (_) {}
    final dir = await getApplicationSupportDirectory();
    final f = File('${dir.path}/pptxgen.bundle.js');
    if (await f.exists() && await f.length() > 1000) return f.readAsString();
    final r = await Dio().get<String>(_libUrl, options: Options(responseType: ResponseType.plain));
    await f.writeAsString(r.data!);
    return r.data!;
  }

  Future<Uint8List> build(Map<String, dynamic> deck) async {
    await ensureReady();
    _pending = Completer<String>();
    await controller.runJavaScript('build(${jsonEncode(jsonEncode(deck))});');
    final r = await _pending!.future.timeout(const Duration(seconds: 120));
    if (r.startsWith('OK:')) return base64Decode(r.substring(3));
    throw Exception(r);
  }
}

const _glue = r'''
function T(d, sl, text, o) {
  sl.addText(text, Object.assign({ fontFace: d.font, rtlMode: d.rtl, align: d.rtl ? 'right' : 'left' }, o));
}
function build(s) {
  try {
    var d = JSON.parse(s), th = d.theme, p = new PptxGenJS();
    var W = 10, H = 5.625;
    p.layout = 'LAYOUT_16x9'; p.title = d.title; p.author = d.author; p.rtlMode = d.rtl;
    p.defineSlideMaster({ title: 'M', background: { color: th.bg } });
    var palette = [th.accent, th.accent2, '6C757D', '20C997', 'FA5252', '845EF7', 'FD7E14', '339AF0'];
    var rx = function (w) { return d.rtl ? W - 0.6 - w : 0.6; };
    d.slides.forEach(function (x) {
      var sl = p.addSlide({ masterName: 'M' });
      var hasBg = !!x.bg, dark = (x.type === 'cover' || x.type === 'thanks');
      if (hasBg) {
        sl.background = { data: x.bg.replace(/^data:/, '') };
        sl.addShape(p.ShapeType.rect, { x: 0, y: 0, w: W, h: H, fill: { color: dark ? '000000' : th.bg, transparency: dark ? 45 : 15 } });
      }
      if (x.type === 'cover' || x.type === 'thanks') {
        if (!hasBg) sl.background = { color: th.accent };
        sl.addShape(p.ShapeType.rect, { x: 0, y: H - 0.35, w: W, h: 0.35, fill: { color: th.accent2 } });
        T(d, sl, x.title, { x: 0.7, y: 1.2, w: 8.6, h: 1.8, fontSize: d.titleSize + 12, bold: true, color: 'FFFFFF', align: 'center', valign: 'middle' });
        if (x.subtitle) T(d, sl, x.subtitle, { x: 0.7, y: 3.1, w: 8.6, h: 0.8, fontSize: d.bodySize + 2, color: 'FFFFFF', align: 'center' });
        if (x.type === 'cover' && d.author) T(d, sl, d.author, { x: 0.7, y: 4.3, w: 8.6, h: 0.5, fontSize: d.bodySize - 2, color: 'F1F1F1', align: 'center' });
        return;
      }
      if (x.type === 'section') {
        sl.addShape(p.ShapeType.rect, { x: d.rtl ? W - 0.45 : 0, y: 0, w: 0.45, h: H, fill: { color: th.accent } });
        sl.addShape(p.ShapeType.rect, { x: d.rtl ? W - 0.45 - 0.15 : 0.45, y: 0, w: 0.15, h: H, fill: { color: th.accent2 } });
        T(d, sl, x.title, { x: 1, y: 1.7, w: 8, h: 1.4, fontSize: d.titleSize + 8, bold: true, color: th.title, valign: 'middle' });
        if (x.subtitle) T(d, sl, x.subtitle, { x: 1, y: 3.1, w: 8, h: 0.8, fontSize: d.bodySize, color: th.text });
      } else {
        T(d, sl, x.title, { x: 0.6, y: 0.3, w: 8.8, h: 0.9, fontSize: d.titleSize, bold: true, color: th.title, valign: 'middle' });
        sl.addShape(p.ShapeType.rect, { x: rx(1.5), y: 1.22, w: 1.5, h: 0.06, fill: { color: th.accent } });
        var bx = { x: 0.7, y: 1.5, w: 8.6, h: 3.6 };
        if (x.type === 'bullets') {
          var items = x.bullets.map(function (b) { return { text: b, options: { bullet: true, breakLine: true } }; });
          T(d, sl, items, Object.assign({ fontSize: d.bodySize, color: th.text, valign: 'top', paraSpaceAfter: 8 }, bx));
        } else if (x.type === 'text') {
          T(d, sl, x.bullets.join('\n'), Object.assign({ fontSize: d.bodySize, color: th.text, valign: 'top' }, bx));
        } else if (x.type === 'image') {
          if (x.image) sl.addImage({ data: x.image.replace(/^data:/, ''), x: 1, y: 1.45, w: 8, h: 3.35, sizing: { type: 'contain', w: 8, h: 3.35 } });
          if (x.subtitle) T(d, sl, x.subtitle, { x: 0.7, y: 4.85, w: 8.6, h: 0.45, fontSize: d.bodySize - 4, italic: true, color: th.text, align: 'center' });
        } else if (x.type === 'chart') {
          var map = { bar: p.charts.BAR, line: p.charts.LINE, pie: p.charts.PIE, doughnut: p.charts.DOUGHNUT, area: p.charts.AREA };
          var pie = x.chartType === 'pie' || x.chartType === 'doughnut';
          var o = Object.assign({
            showLegend: true, legendPos: 'b', legendFontFace: d.font, legendColor: th.text,
            chartColors: pie ? palette.slice(0, Math.max(x.values.length, 1)) : [th.accent],
            catAxisLabelColor: th.text, valAxisLabelColor: th.text,
            catAxisLabelFontFace: d.font, valAxisLabelFontFace: d.font,
            dataLabelColor: th.text, dataLabelFontFace: d.font,
            showValue: !pie, showPercent: pie, valGridLine: { color: 'CCCCCC', size: 0.5 }
          }, bx);
          sl.addChart(map[x.chartType] || p.charts.BAR, [{ name: x.series || x.title, labels: x.labels, values: x.values }], o);
        } else if (x.type === 'table') {
          var rows = x.rows.map(function (r, i) {
            return r.map(function (c) {
              return i === 0
                ? { text: c, options: { bold: true, color: 'FFFFFF', fill: { color: th.accent } } }
                : { text: c, options: { color: th.text } };
            });
          });
          if (rows.length) sl.addTable(rows, { x: 0.7, y: 1.5, w: 8.6, fontFace: d.font, fontSize: d.bodySize - 2, rtlMode: d.rtl, align: d.rtl ? 'right' : 'left', border: { type: 'solid', color: 'BBBBBB', pt: 1 }, valign: 'middle' });
        }
      }
      if (d.numbers) sl.slideNumber = { x: d.rtl ? 0.3 : 9.1, y: 5.2, color: th.text, fontFace: d.font, fontSize: 10 };
    });
    p.write({ outputType: 'base64' }).then(function (b) { Pptx.postMessage('OK:' + b); })
      .catch(function (e) { Pptx.postMessage('ERR:' + e); });
  } catch (e) { Pptx.postMessage('ERR:' + e); }
}
''';
