#!/usr/bin/env bash
# Run once (locally or in CI) from project root
set -e
flutter create --org com.powerpointverse --project-name powerpoint_verse --platforms android .
rm -rf test
M=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="PowerPoint Verse"/' $M
grep -q 'permission.INTERNET' $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <queries><intent><action android:name="android.speech.RecognitionService"/></intent></queries>\n    <application#' $M
# V2Ray core needs minSdk 23 and extractNativeLibs
for G in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$G" ] && sed -i 's/minSdkVersion flutter.minSdkVersion/minSdkVersion 23/; s/minSdk = flutter.minSdkVersion/minSdk = 23/' "$G"
done
grep -q extractNativeLibs $M || sed -i 's#<application#<application android:extractNativeLibs="true"#' $M
mkdir -p assets/web
curl -L -o assets/web/pptxgen.bundle.js https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js || true
flutter pub get
