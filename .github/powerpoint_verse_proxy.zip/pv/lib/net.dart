import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:socks5_proxy/socks_client.dart';
import 'models.dart';

/// پورت‌های پیش‌فرض پروکسی محلی هسته V2Ray (حالت proxyOnly)
const kV2rayHttpPort = 10809;

class Net {
  static InternetAddress? _socksAddr;

  /// قبل از اولین درخواست صدا زده می‌شود (برای resolve کردن هاست SOCKS5)
  static Future<void> prepare() async {
    _socksAddr = null;
    if (app.proxyMode == 'manual' && app.proxyType == 'socks5' && app.proxyHost.isNotEmpty) {
      _socksAddr = InternetAddress.tryParse(app.proxyHost);
      if (_socksAddr == null) {
        try {
          final l = await InternetAddress.lookup(app.proxyHost);
          if (l.isNotEmpty) _socksAddr = l.first;
        } catch (_) {}
      }
    }
  }

  static Dio dio({Duration receive = const Duration(seconds: 60)}) {
    final d = Dio(BaseOptions(connectTimeout: const Duration(seconds: 30), receiveTimeout: receive));
    d.httpClientAdapter = IOHttpClientAdapter(createHttpClient: () {
      final c = HttpClient();
      _apply(c);
      return c;
    });
    return d;
  }

  static void _apply(HttpClient c) {
    switch (app.proxyMode) {
      case 'manual':
        final port = int.tryParse(app.proxyPort);
        if (app.proxyHost.isEmpty || port == null) return;
        if (app.proxyType == 'socks5') {
          if (_socksAddr != null) {
            SocksTCPClient.assignToHttpClient(c, [ProxySettings(_socksAddr!, port)]);
          }
        } else {
          c.findProxy = (_) => 'PROXY ${app.proxyHost}:$port';
        }
        break;
      case 'v2ray':
        if (V2.running) c.findProxy = (_) => 'PROXY 127.0.0.1:$kV2rayHttpPort';
        break;
    }
  }
}

class V2 {
  static final status = ValueNotifier<String>('DISCONNECTED');
  static final core = FlutterV2ray(onStatusChanged: (s) => status.value = s.state);
  static bool _inited = false;
  static bool get running => status.value == 'CONNECTED';

  static const schemes = ['vmess://', 'vless://', 'trojan://', 'ss://'];

  /// از متن چسبانده‌شده، لینک‌های معتبر را بیرون می‌کشد (هر خط یک لینک)
  static List<String> links(String raw) => raw
      .split(RegExp(r'[\r\n]+'))
      .map((e) => e.trim())
      .where((e) => schemes.any(e.startsWith))
      .toList();

  static String remark(String link) {
    try {
      final r = FlutterV2ray.parseFromURL(link).remark;
      return r.isEmpty ? link.substring(0, link.length.clamp(0, 30)) : r;
    } catch (_) {
      return 'نامعتبر';
    }
  }

  /// دریافت لینک ساب‌اسکریپشن (http/https) و تبدیل به لیست کانفیگ‌ها
  static Future<String> fetchSubscription(String url) async {
    final r = await Dio(BaseOptions(connectTimeout: const Duration(seconds: 20)))
        .get<String>(url.trim(), options: Options(responseType: ResponseType.plain, headers: {'User-Agent': 'v2rayNG'}));
    var body = (r.data ?? '').trim();
    if (links(body).isEmpty) {
      try {
        body = utf8.decode(base64.decode(base64.normalize(body)));
      } catch (_) {}
    }
    return links(body).join('\n');
  }

  static Future<void> start(String link) async {
    if (!_inited) {
      await core.initializeV2Ray();
      _inited = true;
    }
    final u = FlutterV2ray.parseFromURL(link.trim());
    // proxyOnly: فقط پروکسی محلی؛ VPN کل گوشی روشن نمی‌شود
    await core.startV2Ray(remark: u.remark, config: u.getFullConfiguration(), proxyOnly: true);
  }

  static Future<void> stop() async {
    if (_inited) await core.stopV2Ray();
  }

  /// بعد از شروع، با یک درخواست آزمایشی مطمئن می‌شویم مسیر کار می‌کند
  static Future<bool> test() async {
    try {
      final r = await Net.dio(receive: const Duration(seconds: 15))
          .get('https://www.gstatic.com/generate_204', options: Options(validateStatus: (_) => true));
      return r.statusCode == 204 || r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
