import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'models.dart';

final Map<int, Uint8List> _imgCache = {};
Uint8List _bytes(String uri) => _imgCache.putIfAbsent(identityHashCode(uri), () => base64Decode(uri.split(',').last));

/// پیش‌نمایش زندهٔ اسلاید؛ هر بخش (عنوان، متن، نمودار، المان‌های اضافه) با کشیدن جابه‌جا و با دستگیرهٔ گوشه تغییر اندازه می‌دهد.
class SlideCanvas extends StatelessWidget {
  final SlideModel slide;
  final Deck deck;
  final String? selected; // 'title' | 'sub' | 'main' | 'e:<id>'
  final ValueChanged<String?> onSelect;
  final VoidCallback onChanged, onCommit;

  const SlideCanvas({
    super.key,
    required this.slide,
    required this.deck,
    required this.selected,
    required this.onSelect,
    required this.onChanged,
    required this.onCommit,
  });

  SlideElement? _el(String key) {
    if (!key.startsWith('e:')) return null;
    for (final e in slide.elements) {
      if (e.id == key.substring(2)) return e;
    }
    return null;
  }

  List<double> _rect(String key) => _el(key)?.rect ?? slide.rect(key);

  void _set(String key, List<double> r) {
    final e = _el(key);
    if (e != null) {
      e.rect = r;
    } else {
      slide.layout[key] = r;
    }
  }

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (ctx, box) {
        final w = box.maxWidth, h = w * 9 / 16, k = w / 720; // یک پوینت = k پیکسل
        final th = deck.theme;
        Color c(String x) => th.c(x);
        final primary = Theme.of(ctx).colorScheme.primary;
        final t = slide.type;
        final dark = t == SlideType.cover || t == SlideType.thanks;
        final rtl = deck.rtl;
        final td = rtl ? TextDirection.rtl : TextDirection.ltr;
        final palette = [c(th.accent), c(th.accent2), c('6C757D'), c('20C997'), c('FA5252'), c('845EF7'), c('FD7E14'), c('339AF0')];

        TextStyle ts(num pt, Color col, {bool bold = false, bool italic = false}) =>
            (previewStyle(deck.font) ?? const TextStyle()).copyWith(
              fontSize: pt * k,
              color: col,
              height: 1.25,
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              fontStyle: italic ? FontStyle.italic : FontStyle.normal,
            );

        Widget txt(String text, TextStyle st, TextAlign al, double vy, {String hint = ''}) => Directionality(
              textDirection: td,
              child: Align(
                alignment: Alignment(0, vy),
                child: SizedBox(
                  width: double.infinity,
                  child: Text(
                    text.isEmpty ? hint : text,
                    textAlign: al,
                    style: text.isEmpty ? st.copyWith(color: st.color?.withOpacity(0.35)) : st,
                  ),
                ),
              ),
            );

        Widget place(String key, Widget child) {
          final r = _rect(key);
          final sel = selected == key;
          return Positioned(
            left: r[0] * w,
            top: r[1] * h,
            width: r[2] * w,
            height: r[3] * h,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onSelect(key),
              onPanStart: (_) => onSelect(key),
              onPanUpdate: (d) {
                final q = [..._rect(key)];
                q[0] = (q[0] + d.delta.dx / w).clamp(0.0, 1.0 - q[2]).toDouble();
                q[1] = (q[1] + d.delta.dy / h).clamp(0.0, 1.0 - q[3]).toDouble();
                _set(key, q);
                onChanged();
              },
              onPanEnd: (_) => onCommit(),
              child: Stack(children: [
                Positioned.fill(child: ClipRect(child: child)),
                Positioned.fill(
                  child: IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        border: Border.all(color: sel ? primary : Colors.grey.withOpacity(0.5), width: sel ? 2 : 0.7),
                      ),
                    ),
                  ),
                ),
                if (sel)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: GestureDetector(
                      onPanUpdate: (d) {
                        final q = [..._rect(key)];
                        q[2] = (q[2] + d.delta.dx / w).clamp(0.08, 1.0 - q[0]).toDouble();
                        q[3] = (q[3] + d.delta.dy / h).clamp(0.06, 1.0 - q[1]).toDouble();
                        _set(key, q);
                        onChanged();
                      },
                      onPanEnd: (_) => onCommit(),
                      child: Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(color: primary, borderRadius: const BorderRadius.only(topLeft: Radius.circular(10))),
                        child: const Icon(Icons.open_in_full, size: 14, color: Colors.white),
                      ),
                    ),
                  ),
              ]),
            ),
          );
        }

        // ---------- پس‌زمینه و تزئینات ----------
        final tr0 = slide.rect('title');
        final deco = <Widget>[
          Positioned.fill(
            child: GestureDetector(onTap: () => onSelect(null), child: ColoredBox(color: dark ? c(th.accent) : c(th.bg))),
          ),
          if (slide.bg != null) Positioned.fill(child: IgnorePointer(child: Image.memory(_bytes(slide.bg!), fit: BoxFit.cover, gaplessPlayback: true))),
          if (slide.bg != null)
            Positioned.fill(child: IgnorePointer(child: ColoredBox(color: dark ? Colors.black.withOpacity(0.45) : c(th.bg).withOpacity(0.85)))),
          if (dark) Positioned(left: 0, right: 0, bottom: 0, height: h * 0.35 / 5.625, child: IgnorePointer(child: ColoredBox(color: c(th.accent2)))),
          if (t == SlideType.section) ...[
            Positioned(left: rtl ? null : 0, right: rtl ? 0 : null, top: 0, bottom: 0, width: w * 0.045, child: IgnorePointer(child: ColoredBox(color: c(th.accent)))),
            Positioned(
              left: rtl ? null : w * 0.045,
              right: rtl ? w * 0.045 : null,
              top: 0,
              bottom: 0,
              width: w * 0.015,
              child: IgnorePointer(child: ColoredBox(color: c(th.accent2))),
            ),
          ],
          if (!dark && t != SlideType.section)
            Positioned(
              left: rtl ? (tr0[0] + tr0[2]) * w - w * 0.15 : tr0[0] * w,
              top: (tr0[1] + tr0[3]) * h + h * 0.02 / 5.625,
              width: w * 0.15,
              height: h * 0.06 / 5.625,
              child: IgnorePointer(child: ColoredBox(color: c(th.accent))),
            ),
        ];

        // ---------- بخش‌های اصلی ----------
        final parts = <Widget>[];
        final titlePt = dark ? deck.titleSize + 12 : (t == SlideType.section ? deck.titleSize + 8 : deck.titleSize);
        parts.add(place(
          'title',
          txt(slide.title, ts(titlePt, dark ? Colors.white : c(th.title), bold: true), dark ? TextAlign.center : TextAlign.start, 0, hint: app.t('title')),
        ));
        if (slide.hasSub) {
          final isImg = t == SlideType.image;
          final pt = isImg ? deck.bodySize - 4 : (dark ? deck.bodySize + 2 : deck.bodySize);
          parts.add(place(
            'sub',
            txt(slide.subtitle, ts(pt, dark ? Colors.white : c(th.text), italic: isImg), (dark || isImg) ? TextAlign.center : TextAlign.start, isImg ? 0 : -1,
                hint: app.t(isImg ? 'caption' : 'subtitle')),
          ));
        }
        if (slide.hasMain) parts.add(place('main', _main(slide, deck, ts, txt, th, palette, k, td)));

        // ---------- المان‌های اضافه ----------
        for (final e in slide.elements) {
          Widget body;
          if (e.kind == 'chart') {
            final (labels, values) = parseChart(e.chartData);
            body = CustomPaint(
              painter: ChartPainter(e.chartType, labels, values, palette, c(th.text), c(th.bg), 10 * k * 1.1),
              child: const SizedBox.expand(),
            );
          } else {
            final al = e.align == 'center' ? TextAlign.center : (e.align == 'end' ? TextAlign.end : TextAlign.start);
            body = txt(e.text, ts(e.size, c(elColor(slide, e, th)), bold: e.bold), al, (e.role == 'title' || e.role == 'name') ? 0 : -1, hint: app.t('role_${e.role}'));
          }
          parts.add(place('e:${e.id}', body));
        }

        return Directionality(
          textDirection: TextDirection.ltr,
          child: Container(
            decoration: BoxDecoration(border: Border.all(color: Colors.black26), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6)]),
            child: SizedBox(width: w, height: h, child: ClipRect(child: Stack(children: [...deco, ...parts]))),
          ),
        );
      });

  static Widget _main(
    SlideModel s,
    Deck d,
    TextStyle Function(num, Color, {bool bold, bool italic}) ts,
    Widget Function(String, TextStyle, TextAlign, double, {String hint}) txt,
    AppTheme th,
    List<Color> palette,
    double k,
    TextDirection td,
  ) {
    switch (s.type) {
      case SlideType.bullets:
        final lines = s.body.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
        final st = ts(d.bodySize, th.c(th.text));
        return Directionality(
          textDirection: td,
          child: Align(
            alignment: Alignment.topCenter,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final l in lines)
                Padding(
                  padding: EdgeInsets.only(bottom: 8 * k),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('•  ', style: st), Expanded(child: Text(l, style: st))]),
                ),
            ]),
          ),
        );
      case SlideType.text:
        return txt(s.body, ts(d.bodySize, th.c(th.text)), TextAlign.start, -1, hint: app.t('body'));
      case SlideType.chart:
        final (labels, values) = parseChart(s.chartData);
        return CustomPaint(
          painter: ChartPainter(s.chartType, labels, values, palette, th.c(th.text), th.c(th.bg), 10 * k * 1.1),
          child: const SizedBox.expand(),
        );
      case SlideType.table:
        final rows = parseTable(s.tableData);
        if (rows.isEmpty) return const SizedBox();
        return Directionality(
          textDirection: td,
          child: Align(
            alignment: Alignment.topCenter,
            child: Table(
              border: TableBorder.all(color: const Color(0xFFBBBBBB), width: 0.6),
              defaultVerticalAlignment: TableCellVerticalAlignment.middle,
              children: [
                for (var i = 0; i < rows.length; i++)
                  TableRow(
                    decoration: i == 0 ? BoxDecoration(color: th.c(th.accent)) : null,
                    children: [
                      for (final cell in rows[i])
                        Padding(
                          padding: EdgeInsets.all(3 * k),
                          child: Text(cell, style: ts(d.bodySize - 2, i == 0 ? Colors.white : th.c(th.text), bold: i == 0)),
                        ),
                    ],
                  ),
              ],
            ),
          ),
        );
      case SlideType.image:
        return s.image == null
            ? Center(child: Icon(Icons.image_outlined, size: 40 * k * 2, color: th.c(th.text).withOpacity(0.3)))
            : Image.memory(_bytes(s.image!), fit: BoxFit.contain, gaplessPlayback: true);
      default:
        return const SizedBox();
    }
  }
}

/// رسم ساده نمودار (ستونی، خطی، ناحیه‌ای، دایره‌ای، حلقه‌ای) برای پیش‌نمایش
class ChartPainter extends CustomPainter {
  final String type;
  final List<String> labels;
  final List<double> values;
  final List<Color> palette;
  final Color text, bg;
  final double fs;

  ChartPainter(this.type, this.labels, this.values, this.palette, this.text, this.bg, this.fs);

  void _t(Canvas c, String s, Offset center, double maxW, {bool above = false}) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: fs, color: text)),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: maxW);
    c.save();
    c.translate(center.dx - tp.width / 2, above ? center.dy - tp.height : center.dy);
    tp.paint(c, Offset.zero);
    c.restore();
  }

  String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

  @override
  void paint(Canvas c, Size s) {
    if (values.isEmpty) {
      _t(c, '—', Offset(s.width / 2, s.height / 2), s.width);
      return;
    }
    final pie = type == 'pie' || type == 'doughnut';
    if (pie) {
      final total = values.fold<double>(0, (a, b) => a + b.abs());
      if (total == 0) return;
      final r = math.min(s.width, s.height) / 2 * 0.9;
      final ctr = Offset(s.width / 2, s.height / 2);
      var a = -math.pi / 2;
      for (var i = 0; i < values.length; i++) {
        final sw = values[i].abs() / total * 2 * math.pi;
        c.drawArc(Rect.fromCircle(center: ctr, radius: r), a, sw, true, Paint()..color = palette[i % palette.length]);
        a += sw;
      }
      if (type == 'doughnut') c.drawCircle(ctr, r * 0.55, Paint()..color = bg);
      return;
    }
    final plot = Rect.fromLTRB(fs * 1.2, fs * 1.6, s.width - fs, s.height - fs * 2.4);
    if (plot.width <= 0 || plot.height <= 0) return;
    final maxV = math.max(values.reduce(math.max), 0.0);
    final minV = math.min(values.reduce(math.min), 0.0);
    final range = (maxV - minV) == 0 ? 1.0 : (maxV - minV);
    double y(double v) => plot.bottom - (v - minV) / range * plot.height;
    final base = y(0);
    c.drawLine(Offset(plot.left, base), Offset(plot.right, base), Paint()..color = text.withOpacity(0.5)..strokeWidth = 1);
    final n = values.length, step = plot.width / n;
    final accent = palette[0];
    if (type == 'line' || type == 'area') {
      final pts = [for (var i = 0; i < n; i++) Offset(plot.left + step * (i + 0.5), y(values[i]))];
      if (type == 'area') {
        final path = Path()..moveTo(pts.first.dx, base);
        for (final p in pts) {
          path.lineTo(p.dx, p.dy);
        }
        path.lineTo(pts.last.dx, base);
        path.close();
        c.drawPath(path, Paint()..color = accent.withOpacity(0.35));
      }
      final line = Paint()..color = accent..strokeWidth = 2..style = PaintingStyle.stroke;
      for (var i = 0; i < pts.length - 1; i++) {
        c.drawLine(pts[i], pts[i + 1], line);
      }
      for (var i = 0; i < pts.length; i++) {
        c.drawCircle(pts[i], 3, Paint()..color = accent);
        _t(c, _fmt(values[i]), Offset(pts[i].dx, pts[i].dy - 3), step, above: true);
      }
    } else {
      for (var i = 0; i < n; i++) {
        final x0 = plot.left + step * i + step * 0.2;
        final top = y(values[i]);
        c.drawRect(Rect.fromLTRB(x0, math.min(top, base), x0 + step * 0.6, math.max(top, base)), Paint()..color = accent);
        _t(c, _fmt(values[i]), Offset(x0 + step * 0.3, math.min(top, base) - 2), step, above: true);
      }
    }
    for (var i = 0; i < n; i++) {
      _t(c, i < labels.length ? labels[i] : '', Offset(plot.left + step * (i + 0.5), s.height - fs * 1.7), step);
    }
  }

  @override
  bool shouldRepaint(covariant ChartPainter o) => true;
}
