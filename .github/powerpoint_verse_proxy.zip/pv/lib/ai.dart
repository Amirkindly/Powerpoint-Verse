import 'dart:convert';
import 'package:dio/dio.dart';
import 'models.dart';
import 'net.dart';

const _system = r'''
You are the presentation-design engine inside the app "PowerPoint Verse".
ALWAYS answer with ONE JSON object and nothing else (no markdown fences):
{
 "reply": "short friendly message to the user, in USER_LANGUAGE (fa = Persian, en = English)",
 "deck": {
   "title": "...", "author": "", "rtl": true|false,
   "colors": {"bg":"RRGGBB","title":"RRGGBB","text":"RRGGBB","accent":"RRGGBB","accent2":"RRGGBB"},
   "slides": [
     {"type":"cover|section|bullets|image|chart|table|text|thanks",
      "title":"", "subtitle":"", "body":"one bullet per line (bullets/text; on chart slides optional: 2-3 short commentary lines shown beside the chart)",
      "imageQuery":"2-4 English words for a photo search (image slides only)",
      "bgQuery":"2-4 English words for a background photo, or empty",
      "chartType":"bar|line|pie|doughnut|area", "series":"", "chartData":"label,number per line",
      "tableData":"CSV rows, first row is header"}
   ]
 }
}
Rules:
- Write all slide text in the language the user wants (default USER_LANGUAGE). rtl=true for Persian/Arabic.
- Omit "deck" entirely if the user only asks a question or chats.
- If CURRENT_DECK_JSON is non-empty and the user asks for a change, return the FULL updated deck; keep unchanged slides (including their imageQuery/bgQuery) as they are.
- New deck: 6-8 slides unless told otherwise; first slide cover, last slide thanks; use section slides for long decks.
- chart slides may carry a short "body" of commentary; the app then shows the chart and the text side by side.
- bullets: 3-5 short lines. Use chart/table only where numbers naturally help; use plausible illustrative numbers and mention in "reply" that they are illustrative.
- Images: imageQuery must be concrete, photographable nouns in English (e.g. "solar panels field"). Use images on about every other content slide. bgQuery for cover/thanks/sections should be a scenic, wide, topic-related photo (e.g. "sunrise over desert").
- colors: pick a palette that fits the topic and the requested colors. title/text must have strong contrast against bg. accent is used for cover backgrounds with white text, so make it medium/dark.
''';

class Ai {
  static Dio get _dio => Net.dio(receive: const Duration(seconds: 150));
  static const _ua = {'User-Agent': 'PowerPointVerse/1.0 (android app)'};

  static Map<String, dynamic> compact(Deck d) => {
        'title': d.title,
        'author': d.author,
        'slides': [
          for (final s in d.slides)
            {
              'type': s.type.name, 'title': s.title, 'subtitle': s.subtitle, 'body': s.body,
              'imageQuery': s.imageQuery, 'bgQuery': s.bgQuery, 'chartType': s.chartType,
              'series': s.seriesName, 'chartData': s.chartData, 'tableData': s.tableData,
            }
        ],
      };

  static String userPrompt(String text) {
    final d = app.deck;
    final hasContent = d.slides.length > 2 || d.slides.any((s) => s.type != SlideType.cover && s.type != SlideType.thanks);
    return 'USER_LANGUAGE: ${app.lang}\nCURRENT_DECK_JSON: ${hasContent ? jsonEncode(compact(d)) : ''}\nREQUEST: $text';
  }

  static Future<String> ask(List<Map<String, String>> history, String user) async {
    await Net.prepare();
    final provider = app.aiProvider;
    final key = app.aiKeys[provider] ?? (provider == 'gemini' ? app.geminiKey : '');
    if (key.trim().isNotEmpty) {
      try {
        switch (provider) {
          case 'chatgpt': return await _openAiCompatible('https://api.openai.com/v1/chat/completions', key, 'gpt-4o-mini', history, user);
          case 'claude': return await _claude(key, history, user);
          case 'gemini': return await _geminiWithKey(key, history, user);
          case 'deepseek': return await _openAiCompatible('https://api.deepseek.com/chat/completions', key, 'deepseek-chat', history, user);
          case 'groq': return await _openAiCompatible('https://api.groq.com/openai/v1/chat/completions', key, 'llama-3.3-70b-versatile', history, user);
        }
      } catch (_) {
        // If the selected provider is unavailable, retain free-mode fallback.
      }
    }
    Object? last;
    for (var i = 0; i < 3; i++) {
      try { return await _pollinations(history, user); }
      catch (e) { last = e; await Future.delayed(const Duration(seconds: 2)); }
    }
    throw last!;
  }

  static List<Map<String, String>> _messages(List<Map<String, String>> history, String user) => [
    {'role': 'system', 'content': _system}, ...history, {'role': 'user', 'content': user},
  ];

  static Future<String> _openAiCompatible(String url, String key, String model,
      List<Map<String, String>> history, String user) async {
    final r = await _dio.post(url,
      options: Options(headers: {'Authorization': 'Bearer $key'}),
      data: {'model': model, 'messages': _messages(history, user), 'response_format': {'type': 'json_object'}});
    return r.data['choices'][0]['message']['content'] as String;
  }

  static Future<String> _claude(String key, List<Map<String, String>> history, String user) async {
    final msgs = [...history, {'role': 'user', 'content': user}];
    final r = await _dio.post('https://api.anthropic.com/v1/messages',
      options: Options(headers: {'x-api-key': key, 'anthropic-version': '2023-06-01'}),
      data: {'model': 'claude-3-5-haiku-latest', 'max_tokens': 8192,
        'system': _system, 'messages': msgs});
    return (r.data['content'] as List).where((x) => x['type'] == 'text').map((x) => x['text']).join('\n');
  }

  static Future<String> _geminiWithKey(String key, List<Map<String, String>> history, String user) async {
    final r = await _dio.post(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
      queryParameters: {'key': key},
      data: {
        'systemInstruction': {'parts': [{'text': _system}]},
        'contents': [
          for (final m in [...history, {'role': 'user', 'content': user}])
            {'role': m['role'] == 'assistant' ? 'model' : 'user', 'parts': [{'text': m['content']}]}
        ],
        'generationConfig': {'responseMimeType': 'application/json'},
      },
    );
    return r.data['candidates'][0]['content']['parts'][0]['text'] as String;
  }

  static Future<String> _pollinations(List<Map<String, String>> history, String user) async {
    final r = await _dio.post('https://text.pollinations.ai/openai', data: {
      'model': 'openai',
      'private': true,
      'messages': [
        {'role': 'system', 'content': _system},
        ...history,
        {'role': 'user', 'content': user},
      ],
    });
    return r.data['choices'][0]['message']['content'] as String;
  }

  static Future<String> _gemini(List<Map<String, String>> history, String user) async {
    final r = await _dio.post(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent',
      queryParameters: {'key': app.geminiKey},
      data: {
        'systemInstruction': {'parts': [{'text': _system}]},
        'contents': [
          for (final m in [...history, {'role': 'user', 'content': user}])
            {'role': m['role'] == 'assistant' ? 'model' : 'user', 'parts': [{'text': m['content']}]}
        ],
        'generationConfig': {'responseMimeType': 'application/json'},
      },
    );
    return r.data['candidates'][0]['content']['parts'][0]['text'] as String;
  }

  static Map<String, dynamic> parse(String s) {
    final a = s.indexOf('{'), b = s.lastIndexOf('}');
    if (a < 0 || b <= a) return {'reply': s.trim()};
    return Map<String, dynamic>.from(jsonDecode(s.substring(a, b + 1)));
  }

  /// Keyless image search + download (Wikimedia Commons). Returns a data URI or null.
  static Future<String?> image(String q) async {
    if (q.trim().isEmpty) return null;
    try {
      final r = await _dio.get('https://commons.wikimedia.org/w/api.php',
          queryParameters: {
            'action': 'query', 'format': 'json', 'generator': 'search', 'gsrnamespace': 6,
            'gsrsearch': '${q.trim()} filetype:bitmap', 'gsrlimit': 12,
            'prop': 'imageinfo', 'iiprop': 'url|mime', 'iiurlwidth': 1280,
          },
          options: Options(headers: _ua));
      final pages = (r.data['query']?['pages'] as Map?)?.values.toList() ?? [];
      pages.sort((a, b) => (a['index'] ?? 0).compareTo(b['index'] ?? 0));
      String? pick;
      String mime = 'image/jpeg';
      for (final p in pages) {
        final info = (p['imageinfo'] as List?)?.first;
        final u = info?['thumburl'] as String?;
        final m = info?['mime'] as String? ?? '';
        final w = (info?['thumbwidth'] ?? 0) as int, h = (info?['thumbheight'] ?? 0) as int;
        if (u == null || (m != 'image/jpeg' && m != 'image/png')) continue;
        if (w > h * 1.15) {
          pick = u;
          mime = m;
          break;
        }
        pick ??= u;
        if (pick == u) mime = m;
      }
      if (pick == null) return null;
      final img = await _dio.get<List<int>>(pick, options: Options(responseType: ResponseType.bytes, headers: _ua));
      return 'data:$mime;base64,${base64Encode(img.data!)}';
    } catch (_) {
      return null;
    }
  }

  static final _hex = RegExp(r'^[0-9A-Fa-f]{6}$');

  static Future<void> applyDeck(Map<String, dynamic> j) async {
    final old = app.deck;
    final slides = <SlideModel>[];
    for (final e in (j['slides'] as List? ?? [])) {
      final m = Map<String, dynamic>.from(e);
      String g(String k) => (m[k] ?? '').toString();
      slides.add(SlideModel(
        type: SlideType.values.firstWhere((t) => t.name == g('type'), orElse: () => SlideType.bullets),
        title: g('title'), subtitle: g('subtitle'), body: g('body').replaceAll('\\n', '\n'),
        imageQuery: g('imageQuery'), bgQuery: g('bgQuery'),
        chartType: ['bar', 'line', 'pie', 'doughnut', 'area'].contains(g('chartType')) ? g('chartType') : 'bar',
        seriesName: g('series'), chartData: g('chartData').replaceAll('\\n', '\n'), tableData: g('tableData').replaceAll('\\n', '\n'),
      ));
    }
    if (slides.isEmpty) return;
    // موقعیت‌ها و المان‌هایی که کاربر دستی روی اسلاید گذاشته حفظ شود
    final rtlNow = j['rtl'] is bool ? j['rtl'] as bool : old.rtl;
    for (var i = 0; i < slides.length; i++) {
      final s = slides[i];
      final o = i < old.slides.length ? old.slides[i] : null;
      if (o != null && o.type == s.type) {
        s.layout.addAll(o.layout);
        s.elements.addAll(o.elements);
      }
      if (s.type == SlideType.chart && s.body.trim().isNotEmpty) {
        final text = s.body.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).map((e) => '• $e').join('\n');
        final ex = s.elements.where((e) => e.kind == 'text' && e.role == 'desc').toList();
        if (ex.isNotEmpty) {
          ex.first.text = text;
        } else {
          final el = SlideElement(kind: 'text', role: 'desc', text: text, size: old.bodySize - 2, rect: [0.07, 0.267, 0.42, 0.64]);
          s.autoSplit(el, rtlNow);
          s.elements.add(el);
        }
      }
    }
    await Future.wait([
      for (var i = 0; i < slides.length; i++)
        () async {
          final s = slides[i];
          final o = i < old.slides.length ? old.slides[i] : null;
          if (s.type == SlideType.image && s.imageQuery.isNotEmpty) {
            s.image = (o != null && o.imageQuery == s.imageQuery && o.image != null) ? o.image : await image(s.imageQuery);
          }
          if (s.bgQuery.isNotEmpty) {
            s.bg = (o != null && o.bgQuery == s.bgQuery && o.bg != null) ? o.bg : await image(s.bgQuery);
          }
        }()
    ]);
    old.title = (j['title'] ?? old.title).toString();
    old.author = (j['author'] ?? old.author).toString();
    if (j['rtl'] is bool) old.rtl = j['rtl'];
    final c = j['colors'];
    if (c is Map) {
      final cc = <String, String>{};
      for (final k in ['bg', 'title', 'text', 'accent', 'accent2']) {
        final v = (c[k] ?? '').toString().replaceAll('#', '');
        if (_hex.hasMatch(v)) cc[k] = v.toUpperCase();
      }
      if (cc.length == 5) {
        old.custom = cc;
        old.themeId = 'custom';
      }
    }
    old.slides = slides;
  }
}
