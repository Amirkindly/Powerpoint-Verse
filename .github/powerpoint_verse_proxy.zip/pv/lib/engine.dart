import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'net.dart';

const _libUrl = 'https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js';

/// Runs PptxGenJS inside a hidden WebView and returns the .pptx bytes.
class PptxEngine {
  late final WebViewController controller;
  final Completer<void> _loaded = Completer<void>();
  Completer<String>? _pending;
  Future<void>? _initFuture;

  PptxEngine() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('Pptx', onMessageReceived: (m) {
        final p = _pending;
        if (p != null && !p.isCompleted) p.complete(m.message);
      })
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
        if (!_loaded.isCompleted) _loaded.complete();
      }));
  }

  Future<void> ensureReady() {
    _initFuture ??= _init().catchError((e) {
      _initFuture = null;
      throw e;
    });
    return _initFuture!;
  }

  Future<void> _init() async {
    await controller.loadHtmlString('<html><body></body></html>');
    await _loaded.future.timeout(const Duration(seconds: 20));
    final lib = await _loadLib();
    await controller.runJavaScript(lib);
    await controller.runJavaScript(_glue);
  }

  Future<String> _loadLib() async {
    try {
      final s = await rootBundle.loadString('assets/web/pptxgen.bundle.js');
      if (s.length > 1000) return s;
    } catch (_) {}
    final dir = await getApplicationSupportDirectory();
    final f = File('${dir.path}/pptxgen.bundle.js');
    if (await f.exists() && await f.length() > 1000) return f.readAsString();
    final r = await Net.dio().get<String>(_libUrl, options: Options(responseType: ResponseType.plain));
    await f.writeAsString(r.data!);
    return r.data!;
  }

  Future<Uint8List> build(Map<String, dynamic> deck) async {
    await ensureReady();
    _pending = Completer<String>();
    await controller.runJavaScript('build(${jsonEncode(jsonEncode(deck))});');
    final r = await _pending!.future.timeout(const Duration(seconds: 120));
    if (r.startsWith('OK:')) return base64Decode(r.substring(3));
    throw Exception(r);
  }
}

const _glue = r'''
function T(d, sl, text, o) {
  sl.addText(text, Object.assign({ fontFace: d.font, rtlMode: d.rtl, align: d.rtl ? 'right' : 'left' }, o));
}
function R(r) { return { x: r[0], y: r[1], w: r[2], h: r[3] }; }
function build(s) {
  try {
    var d = JSON.parse(s), th = d.theme, p = new PptxGenJS();
    var W = 10, H = 5.625;
    p.layout = 'LAYOUT_16x9'; p.title = d.title; p.author = d.author; p.rtlMode = d.rtl;
    p.defineSlideMaster({ title: 'M', background: { color: th.bg } });
    var palette = [th.accent, th.accent2, '6C757D', '20C997', 'FA5252', '845EF7', 'FD7E14', '339AF0'];
    var map = { bar: p.charts.BAR, line: p.charts.LINE, pie: p.charts.PIE, doughnut: p.charts.DOUGHNUT, area: p.charts.AREA };

    function addChart(sl, type, name, labels, values, r) {
      if (!values || !values.length) return;
      var pie = type === 'pie' || type === 'doughnut';
      var o = Object.assign({
        showLegend: true, legendPos: 'b', legendFontFace: d.font, legendColor: th.text,
        chartColors: pie ? palette.slice(0, Math.max(values.length, 1)) : [th.accent],
        catAxisLabelColor: th.text, valAxisLabelColor: th.text,
        catAxisLabelFontFace: d.font, valAxisLabelFontFace: d.font,
        dataLabelColor: th.text, dataLabelFontFace: d.font,
        showValue: !pie, showPercent: pie, valGridLine: { color: 'CCCCCC', size: 0.5 }
      }, R(r));
      sl.addChart(map[type] || p.charts.BAR, [{ name: name, labels: labels, values: values }], o);
    }
    // المان‌های آزاد (عنوان / نام / توضیحات / متن / نمودار) در جای دقیقی که کاربر روی اسلاید گذاشته
    function addEls(sl, x) {
      (x.elements || []).forEach(function (e) {
        if (e.kind === 'chart') addChart(sl, e.chartType, e.series || 'Series', e.labels, e.values, e.rect);
        else T(d, sl, e.text, Object.assign({ fontSize: e.size, bold: e.bold, color: e.color, align: e.align, valign: e.valign }, R(e.rect)));
      });
    }

    d.slides.forEach(function (x) {
      var rc = x.rects || {};
      var sl = p.addSlide({ masterName: 'M' });
      var hasBg = !!x.bg, dark = (x.type === 'cover' || x.type === 'thanks');
      if (hasBg) {
        sl.background = { data: x.bg.replace(/^data:/, '') };
        sl.addShape(p.ShapeType.rect, { x: 0, y: 0, w: W, h: H, fill: { color: dark ? '000000' : th.bg, transparency: dark ? 45 : 15 } });
      }
      if (dark) {
        if (!hasBg) sl.background = { color: th.accent };
        sl.addShape(p.ShapeType.rect, { x: 0, y: H - 0.35, w: W, h: 0.35, fill: { color: th.accent2 } });
        T(d, sl, x.title, Object.assign({ fontSize: d.titleSize + 12, bold: true, color: 'FFFFFF', align: 'center', valign: 'middle' }, R(rc.title || [0.7, 1.2, 8.6, 1.8])));
        if (x.subtitle) T(d, sl, x.subtitle, Object.assign({ fontSize: d.bodySize + 2, color: 'FFFFFF', align: 'center' }, R(rc.sub || [0.7, 3.1, 8.6, 0.8])));
        if (x.type === 'cover' && d.author) T(d, sl, d.author, { x: 0.7, y: 4.3, w: 8.6, h: 0.5, fontSize: d.bodySize - 2, color: 'F1F1F1', align: 'center' });
        addEls(sl, x);
        return;
      }
      if (x.type === 'section') {
        sl.addShape(p.ShapeType.rect, { x: d.rtl ? W - 0.45 : 0, y: 0, w: 0.45, h: H, fill: { color: th.accent } });
        sl.addShape(p.ShapeType.rect, { x: d.rtl ? W - 0.45 - 0.15 : 0.45, y: 0, w: 0.15, h: H, fill: { color: th.accent2 } });
        T(d, sl, x.title, Object.assign({ fontSize: d.titleSize + 8, bold: true, color: th.title, valign: 'middle' }, R(rc.title || [1, 1.7, 8, 1.4])));
        if (x.subtitle) T(d, sl, x.subtitle, Object.assign({ fontSize: d.bodySize, color: th.text }, R(rc.sub || [1, 3.1, 8, 0.8])));
      } else {
        var tr = rc.title || [0.6, 0.3, 8.8, 0.9];
        T(d, sl, x.title, Object.assign({ fontSize: d.titleSize, bold: true, color: th.title, valign: 'middle' }, R(tr)));
        sl.addShape(p.ShapeType.rect, { x: d.rtl ? tr[0] + tr[2] - 1.5 : tr[0], y: tr[1] + tr[3] + 0.02, w: 1.5, h: 0.06, fill: { color: th.accent } });
        var mr = rc.main || [0.7, 1.5, 8.6, 3.6];
        var bx = R(mr);
        if (x.type === 'bullets') {
          var items = x.bullets.map(function (b) { return { text: b, options: { bullet: true, breakLine: true } }; });
          T(d, sl, items, Object.assign({ fontSize: d.bodySize, color: th.text, valign: 'top', paraSpaceAfter: 8 }, bx));
        } else if (x.type === 'text') {
          T(d, sl, x.bullets.join('\n'), Object.assign({ fontSize: d.bodySize, color: th.text, valign: 'top' }, bx));
        } else if (x.type === 'image') {
          if (x.image) sl.addImage({ data: x.image.replace(/^data:/, ''), x: bx.x, y: bx.y, w: bx.w, h: bx.h, sizing: { type: 'contain', w: bx.w, h: bx.h } });
          if (x.subtitle) T(d, sl, x.subtitle, Object.assign({ fontSize: d.bodySize - 4, italic: true, color: th.text, align: 'center' }, R(rc.sub || [0.7, 4.85, 8.6, 0.45])));
        } else if (x.type === 'chart') {
          addChart(sl, x.chartType, x.series || x.title, x.labels, x.values, mr);
        } else if (x.type === 'table') {
          var rows = x.rows.map(function (r, i) {
            return r.map(function (c) {
              return i === 0
                ? { text: c, options: { bold: true, color: 'FFFFFF', fill: { color: th.accent } } }
                : { text: c, options: { color: th.text } };
            });
          });
          if (rows.length) sl.addTable(rows, { x: bx.x, y: bx.y, w: bx.w, fontFace: d.font, fontSize: d.bodySize - 2, rtlMode: d.rtl, align: d.rtl ? 'right' : 'left', border: { type: 'solid', color: 'BBBBBB', pt: 1 }, valign: 'middle' });
        }
      }
      addEls(sl, x);
      if (d.numbers) sl.slideNumber = { x: d.rtl ? 0.3 : 9.1, y: 5.2, color: th.text, fontFace: d.font, fontSize: 10 };
    });
    p.write({ outputType: 'base64' }).then(function (b) { Pptx.postMessage('OK:' + b); })
      .catch(function (e) { Pptx.postMessage('ERR:' + e); });
  } catch (e) { Pptx.postMessage('ERR:' + e); }
}
''';
