import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'ai.dart';
import 'canvas.dart';
import 'engine.dart';
import 'models.dart';
import 'net.dart';

final engine = PptxEngine();
final tabIndex = ValueNotifier<int>(0);
Future<void> exportDeck(BuildContext c) => const HomeScreen()._export(c);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  runApp(const VerseApp());
  () async {
    await Net.prepare();
    if (app.proxyMode == 'v2ray' && app.v2rayAuto) {
      final l = V2.links(app.v2rayRaw);
      if (l.isNotEmpty) {
        try {
          await V2.start(l[app.v2rayIndex.clamp(0, l.length - 1)]);
          await Future.delayed(const Duration(seconds: 2));
        } catch (_) {}
      }
    }
    engine.ensureReady().catchError((_) {});
  }();
}

Future<void> push(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class VerseApp extends StatelessWidget {
  const VerseApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (_, __) => MaterialApp(
          title: 'PowerPoint Verse',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: const Color(0xFF6C4DFF),
            textTheme: app.lang == 'fa' ? GoogleFonts.vazirmatnTextTheme() : null,
          ),
          builder: (c, child) => Directionality(
            textDirection: app.lang == 'fa' ? TextDirection.rtl : TextDirection.ltr,
            child: child!,
          ),
          home: const SplashScreen(),
        ),
      );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 500),
          pageBuilder: (_, __, ___) => const RootScreen(),
          transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF6C4DFF), Color(0xFF2D1B8F)],
          ),
        ),
        child: SafeArea(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeOutBack,
            builder: (_, v, child) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.scale(scale: 0.8 + 0.2 * v, child: child)),
            child: Column(children: [
              const Spacer(flex: 3),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(32)),
                child: const Icon(Icons.slideshow_rounded, size: 72, color: Colors.white),
              ),
              const SizedBox(height: 24),
              const Text('PowerPoint Verse',
                  style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              const Spacer(flex: 3),
              Text(app.t('madeBy'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
              const SizedBox(height: 4),
              Text(app.t('author_name'), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              const Directionality(
                textDirection: TextDirection.ltr,
                child: Text('@Human_kindly', style: TextStyle(color: Colors.white70, fontSize: 15)),
              ),
              const SizedBox(height: 32),
            ]),
          ),
        ),
      ),
    );
  }
}

class RootScreen extends StatelessWidget {
  const RootScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([tabIndex, app]),
        builder: (_, __) => Scaffold(
          body: IndexedStack(index: tabIndex.value, children: const [HomeScreen(), AssistantScreen()]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tabIndex.value,
            onDestinationSelected: (i) => tabIndex.value = i,
            destinations: [
              NavigationDestination(icon: const Icon(Icons.slideshow), label: app.t('slidesTab')),
              NavigationDestination(icon: const Icon(Icons.auto_awesome), label: app.t('assistant')),
            ],
          ),
        ),
      );
}

// ───────────────────────── Home ─────────────────────────
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _add(BuildContext c) {
    showModalBottomSheet(
      context: c,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          child: Column(children: [
            for (final ty in SlideType.values)
              ListTile(
                leading: Icon(typeIcon(ty)),
                title: Text(app.t(ty.name)),
                onTap: () async {
                  Navigator.pop(c);
                  final s = SlideModel.create(ty);
                  app.deck.slides.add(s);
                  app.save();
                  await push(c, SlideEditor(slide: s));
                  app.save();
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<void> _export(BuildContext c) async {
    showDialog(
      context: c,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        content: Row(children: [const CircularProgressIndicator(), const SizedBox(width: 16), Text(app.t('exporting'))]),
      ),
    );
    try {
      final bytes = await engine.build(app.deck.toPptJson());
      final dir = await getApplicationDocumentsDirectory();
      var name = app.deck.title.replaceAll(RegExp(r'[^\w\u0600-\u06FF\- ]'), '_').trim();
      if (name.isEmpty) name = 'presentation';
      final f = File('${dir.path}/$name.pptx');
      await f.writeAsBytes(bytes);
      if (c.mounted) Navigator.pop(c);
      await Share.shareXFiles([
        XFile(f.path, mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation')
      ]);
    } catch (e) {
      if (c.mounted) {
        Navigator.pop(c);
        toast(c, '${app.t('error')}: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final slides = app.deck.slides;
          return Scaffold(
            appBar: AppBar(
              title: const Text('PowerPoint Verse'),
              actions: [
                IconButton(
                    tooltip: app.t('design'),
                    icon: const Icon(Icons.palette_outlined),
                    onPressed: () => push(context, const DesignScreen())),
                IconButton(
                    tooltip: app.t('settings'),
                    icon: const Icon(Icons.settings_outlined),
                    onPressed: () => push(context, const SettingsScreen())),
              ],
            ),
            body: Stack(children: [
              Positioned.fill(
                child: slides.isEmpty
                    ? Center(child: Text(app.t('empty')))
                    : ReorderableListView.builder(
                        padding: const EdgeInsets.fromLTRB(8, 8, 8, 96),
                        itemCount: slides.length,
                        onReorder: (o, n) {
                          if (n > o) n--;
                          slides.insert(n, slides.removeAt(o));
                          app.save();
                        },
                        itemBuilder: (_, i) {
                          final s = slides[i];
                          return Card(
                            key: ValueKey(s.id),
                            child: ListTile(
                              leading: CircleAvatar(child: Icon(typeIcon(s.type), size: 20)),
                              title: Text(s.title.isEmpty ? app.t(s.type.name) : s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text('${i + 1} • ${app.t(s.type.name)}'),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () {
                                  slides.removeAt(i);
                                  app.save();
                                },
                              ),
                              onTap: () async {
                                await push(context, SlideEditor(slide: s));
                                app.save();
                              },
                            ),
                          );
                        },
                      ),
              ),
              // hidden WebView that runs PptxGenJS
              Positioned(left: 0, top: 0, child: SizedBox(width: 1, height: 1, child: WebViewWidget(controller: engine.controller))),
            ]),
            floatingActionButton: Row(mainAxisSize: MainAxisSize.min, children: [
              FloatingActionButton.extended(
                  heroTag: 'e', onPressed: () => _export(context), icon: const Icon(Icons.ios_share), label: Text(app.t('export'))),
              const SizedBox(width: 12),
              FloatingActionButton(heroTag: 'a', tooltip: app.t('add'), onPressed: () => _add(context), child: const Icon(Icons.add)),
            ]),
          );
        },
      );
}

// ───────────────────────── Slide editor ─────────────────────────
class SlideEditor extends StatefulWidget {
  final SlideModel slide;
  const SlideEditor({super.key, required this.slide});
  @override
  State<SlideEditor> createState() => _SlideEditorState();
}

class _SlideEditorState extends State<SlideEditor> {
  bool busy = false;
  bool _bgMode = false;
  SlideModel get s => widget.slide;

  Widget field(String label, String init, void Function(String) cb, {int lines = 1, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          initialValue: init,
          minLines: lines,
          maxLines: lines == 1 ? 1 : lines + 6,
          onChanged: (v) {
            cb(v);
            setState(() {});
          },
          decoration: InputDecoration(labelText: label, helperText: hint, helperMaxLines: 3, border: const OutlineInputBorder()),
        ),
      );

  Future<void> _setImage(Uint8List bytes, String mime) async {
    if (mime != 'image/png' && mime != 'image/jpeg' && mime != 'image/gif') {
      final codec = await ui.instantiateImageCodec(bytes);
      final fr = await codec.getNextFrame();
      final data = await fr.image.toByteData(format: ui.ImageByteFormat.png);
      bytes = data!.buffer.asUint8List();
      mime = 'image/png';
    }
    final v = 'data:$mime;base64,${base64Encode(bytes)}';
    setState(() {
      if (_bgMode) {
        s.bg = v;
      } else {
        s.image = v;
      }
    });
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() => busy = true);
    try {
      await job();
    } catch (e) {
      if (mounted) toast(context, '${app.t('error')}: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _gallery() => _run(() async {
        final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
        if (x == null) return;
        await _setImage(await x.readAsBytes(), x.path.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');
      });

  Future<void> _fromUrl(String url) => _run(() async {
        final r = await Net.dio().get<List<int>>(url, options: Options(responseType: ResponseType.bytes));
        final ct = (r.headers.value('content-type') ?? 'image/jpeg').split(';').first;
        await _setImage(Uint8List.fromList(r.data!), ct.startsWith('image/') ? ct : 'image/jpeg');
      });

  Future<void> _askUrl() async {
    final ctl = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(app.t('imageUrl')),
        content: TextField(controller: ctl, keyboardType: TextInputType.url, textDirection: TextDirection.ltr),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(app.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: Text(app.t('ok'))),
        ],
      ),
    );
    if (url != null && url.isNotEmpty) await _fromUrl(url);
  }

  Future<void> _pexels() async {
    final url = await showDialog<String>(context: context, builder: (_) => const PexelsDialog());
    if (url != null) await _fromUrl(url);
  }

  // ───── انتخاب و افزودن المان‌ها روی اسلاید ─────
  String? sel = 'title';

  SlideElement? get selEl {
    final k = sel;
    if (k == null || !k.startsWith('e:')) return null;
    for (final e in s.elements) {
      if ('e:${e.id}' == k) return e;
    }
    return null;
  }

  void _addText(String role) {
    final d = app.deck;
    final el = SlideElement(kind: 'text', role: role);
    switch (role) {
      case 'title':
        el.text = app.t('elTitleText');
        el.size = (d.titleSize * 0.75).round();
        el.bold = true;
        el.align = 'center';
        el.rect = [0.08, 0.06, 0.84, 0.16];
        break;
      case 'name':
        el.text = app.t('elNameText');
        el.size = d.bodySize;
        el.bold = true;
        el.rect = [0.06, 0.84, 0.4, 0.1];
        break;
      case 'desc':
        el.text = app.t('elDescText');
        el.size = d.bodySize - 2;
        el.rect = [0.08, 0.58, 0.84, 0.22];
        break;
      default:
        el.text = app.t('elTextText');
        el.size = d.bodySize;
        el.rect = [0.08, 0.4, 0.84, 0.2];
    }
    _shift(el);
    if (role == 'desc' || role == 'text') s.autoSplit(el, d.rtl);
    setState(() {
      s.elements.add(el);
      sel = 'e:${el.id}';
    });
    app.save();
  }

  void _addChart() {
    final el = SlideElement(
      kind: 'chart',
      chartType: 'bar',
      seriesName: app.t('chart'),
      chartData: 'Q1,10\nQ2,25\nQ3,18\nQ4,32',
      rect: [0.15, 0.3, 0.7, 0.6],
    );
    _shift(el);
    s.autoSplit(el, app.deck.rtl);
    setState(() {
      s.elements.add(el);
      sel = 'e:${el.id}';
    });
    app.save();
  }

  /// المان‌های تازه کمی جابه‌جا قرار می‌گیرند تا روی هم نیفتند
  void _shift(SlideElement el) {
    final dx = 0.02 * (s.elements.length % 4);
    if (el.rect[0] + dx + el.rect[2] <= 1 && el.rect[1] + dx + el.rect[3] <= 1) {
      el.rect = [el.rect[0] + dx, el.rect[1] + dx, el.rect[2], el.rect[3]];
    }
  }

  String _selName() {
    final k = sel;
    if (k == null) return '';
    final e = selEl;
    if (e != null) return e.kind == 'chart' ? app.t('chart') : app.t('role_${e.role}');
    if (k == 'title') return app.t('title');
    if (k == 'sub') return app.t(s.type == SlideType.image ? 'caption' : 'subtitle');
    return app.t(s.type.name);
  }

  Widget _panel(BuildContext context) {
    final k = sel;
    if (k == null) {
      return Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(app.t('selectHint'), style: Theme.of(context).textTheme.bodySmall));
    }
    final el = selEl;
    final r = el?.rect ?? s.rect(k);
    String pct(double v) => '${(v * 100).round()}%';
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(_selName(), style: Theme.of(context).textTheme.titleSmall)),
            if (el != null)
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    s.elements.remove(el);
                    sel = null;
                  });
                  app.save();
                },
                icon: const Icon(Icons.delete_outline),
                label: Text(app.t('delete')),
              )
            else if (s.layout.containsKey(k))
              TextButton(
                onPressed: () {
                  setState(() => s.layout.remove(k));
                  app.save();
                },
                child: Text(app.t('resetPos')),
              ),
          ]),
          Text('${app.t('position')}: ${pct(r[0])} ، ${pct(r[1])}      ${app.t('size')}: ${pct(r[2])} × ${pct(r[3])}',
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          if (el == null) Text(app.t('editBelow'), style: Theme.of(context).textTheme.bodySmall),
          if (el != null && el.kind == 'text') ...[
            TextFormField(
              key: ValueKey('t${el.id}'),
              initialValue: el.text,
              minLines: 2,
              maxLines: 6,
              onChanged: (v) => setState(() => el.text = v),
              decoration: InputDecoration(labelText: app.t('role_${el.role}'), border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Text(app.t('fontSize')),
              IconButton(onPressed: el.size > 8 ? () => setState(() => el.size -= 2) : null, icon: const Icon(Icons.remove_circle_outline)),
              Text('${el.size}'),
              IconButton(onPressed: el.size < 96 ? () => setState(() => el.size += 2) : null, icon: const Icon(Icons.add_circle_outline)),
              const Spacer(),
              Text(app.t('bold')),
              Switch(value: el.bold, onChanged: (v) => setState(() => el.bold = v)),
            ]),
            SegmentedButton<String>(
              segments: [
                ButtonSegment(value: 'start', icon: const Icon(Icons.format_align_right), label: Text(app.t('alignStart'))),
                ButtonSegment(value: 'center', icon: const Icon(Icons.format_align_center), label: Text(app.t('alignCenter'))),
                ButtonSegment(value: 'end', icon: const Icon(Icons.format_align_left), label: Text(app.t('alignEnd'))),
              ],
              selected: {el.align},
              onSelectionChanged: (v) => setState(() => el.align = v.first),
            ),
          ],
          if (el != null && el.kind == 'chart') ...[
            DropdownButtonFormField<String>(
              key: ValueKey('ct${el.id}'),
              value: el.chartType,
              decoration: InputDecoration(labelText: app.t('chartType'), border: const OutlineInputBorder()),
              items: [for (final x in ['bar', 'line', 'pie', 'doughnut', 'area']) DropdownMenuItem(value: x, child: Text(app.t(x)))],
              onChanged: (v) => setState(() => el.chartType = v!),
            ),
            const SizedBox(height: 8),
            TextFormField(
              key: ValueKey('cs${el.id}'),
              initialValue: el.seriesName,
              onChanged: (v) => el.seriesName = v,
              decoration: InputDecoration(labelText: app.t('series'), border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 8),
            TextFormField(
              key: ValueKey('cd${el.id}'),
              initialValue: el.chartData,
              minLines: 4,
              maxLines: 10,
              onChanged: (v) => setState(() => el.chartData = v),
              decoration: InputDecoration(labelText: app.t('chartDataLbl'), helperText: app.t('chartHint'), helperMaxLines: 3, border: const OutlineInputBorder()),
            ),
          ],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = s.type;
    final hasSub = s.hasSub;
    return Scaffold(
      appBar: AppBar(title: Text(app.t(t.name))),
      body: Column(children: [
        if (busy) const LinearProgressIndicator(),
        // پیش‌نمایش زندهٔ اسلاید: همیشه بالای صفحه می‌ماند
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: SlideCanvas(
            slide: s,
            deck: app.deck,
            selected: sel,
            onSelect: (k) => setState(() => sel = k),
            onChanged: () => setState(() {}),
            onCommit: app.save,
          ),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Text(app.t('addEl'), style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 6),
            Wrap(spacing: 8, runSpacing: 4, children: [
              ActionChip(avatar: const Icon(Icons.title, size: 18), label: Text(app.t('role_title')), onPressed: () => _addText('title')),
              ActionChip(avatar: const Icon(Icons.person_outline, size: 18), label: Text(app.t('role_name')), onPressed: () => _addText('name')),
              ActionChip(avatar: const Icon(Icons.notes, size: 18), label: Text(app.t('role_desc')), onPressed: () => _addText('desc')),
              ActionChip(avatar: const Icon(Icons.text_fields, size: 18), label: Text(app.t('role_text')), onPressed: () => _addText('text')),
              ActionChip(avatar: const Icon(Icons.bar_chart, size: 18), label: Text(app.t('chart')), onPressed: _addChart),
            ]),
            const SizedBox(height: 12),
            _panel(context),
            const Divider(height: 24),
            Text(app.t('slideContent'), style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            field(app.t('title'), s.title, (v) => s.title = v),
            if (hasSub) field(t == SlideType.image ? app.t('caption') : app.t('subtitle'), s.subtitle, (v) => s.subtitle = v),
            if (t == SlideType.bullets || t == SlideType.text) field(app.t('body'), s.body, (v) => s.body = v, lines: 6, hint: app.t('bodyHint')),
            if (t == SlideType.image) ...[
              if (s.image != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(base64Decode(s.image!.split(',').last), height: 200, fit: BoxFit.contain)),
                ),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(onPressed: () { _bgMode = false; _gallery(); }, icon: const Icon(Icons.photo_library_outlined), label: Text(app.t('gallery'))),
                OutlinedButton.icon(onPressed: () { _bgMode = false; _askUrl(); }, icon: const Icon(Icons.link), label: Text(app.t('url'))),
                OutlinedButton.icon(onPressed: () { _bgMode = false; _pexels(); }, icon: const Icon(Icons.search), label: Text(app.t('search'))),
              ]),
              const SizedBox(height: 12),
            ],
            if (t == SlideType.chart) ...[
              DropdownButtonFormField<String>(
                value: s.chartType,
                decoration: InputDecoration(labelText: app.t('chartType'), border: const OutlineInputBorder()),
                items: [for (final k in ['bar', 'line', 'pie', 'doughnut', 'area']) DropdownMenuItem(value: k, child: Text(app.t(k)))],
                onChanged: (v) => setState(() => s.chartType = v!),
              ),
              const SizedBox(height: 12),
              field(app.t('series'), s.seriesName, (v) => s.seriesName = v),
              field(app.t('chart'), s.chartData, (v) => s.chartData = v, lines: 6, hint: app.t('chartHint')),
            ],
            if (t == SlideType.table) field(app.t('table'), s.tableData, (v) => s.tableData = v, lines: 6, hint: app.t('tableHint')),
            const Divider(height: 32),
            Text(app.t('bgImage'), style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            if (s.bg != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(base64Decode(s.bg!.split(',').last), height: 120, fit: BoxFit.cover)),
              ),
            Wrap(spacing: 8, children: [
              OutlinedButton.icon(onPressed: () { _bgMode = true; _gallery(); }, icon: const Icon(Icons.photo_library_outlined), label: Text(app.t('gallery'))),
              OutlinedButton.icon(onPressed: () { _bgMode = true; _askUrl(); }, icon: const Icon(Icons.link), label: Text(app.t('url'))),
              OutlinedButton.icon(onPressed: () { _bgMode = true; _pexels(); }, icon: const Icon(Icons.search), label: Text(app.t('search'))),
              if (s.bg != null) TextButton(onPressed: () => setState(() => s.bg = null), child: Text(app.t('remove'))),
            ]),
          ]),
        ),
      ]),
    );
  }
}

class PexelsDialog extends StatefulWidget {
  const PexelsDialog({super.key});
  @override
  State<PexelsDialog> createState() => _PexelsDialogState();
}

/// Keyless online image search (Wikimedia Commons).
class _PexelsDialogState extends State<PexelsDialog> {
  final q = TextEditingController();
  List<Map<String, String>> res = [];
  bool loading = false;

  Future<void> _go() async {
    if (q.text.trim().isEmpty) return;
    setState(() => loading = true);
    try {
      final r = await Net.dio().get('https://commons.wikimedia.org/w/api.php',
          queryParameters: {
            'action': 'query', 'format': 'json', 'generator': 'search', 'gsrnamespace': 6,
            'gsrsearch': '${q.text.trim()} filetype:bitmap', 'gsrlimit': 18,
            'prop': 'imageinfo', 'iiprop': 'url|mime', 'iiurlwidth': 1280,
          },
          options: Options(headers: {'User-Agent': 'PowerPointVerse/1.0 (android app)'}));
      final pages = (r.data['query']?['pages'] as Map?)?.values ?? [];
      res = [];
      for (final p in pages) {
        final info = (p['imageinfo'] as List?)?.first;
        final u = info?['thumburl'] as String?;
        final mime = info?['mime'] as String? ?? '';
        if (u != null && (mime == 'image/jpeg' || mime == 'image/png')) res.add({'thumb': u, 'large': u});
      }
    } catch (e) {
      if (mounted) toast(context, '${app.t('error')}: $e');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: TextField(
          controller: q,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _go(),
          decoration: InputDecoration(hintText: app.t('query'), suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _go)),
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 360,
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : GridView.count(
                  crossAxisCount: 3,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  children: [
                    for (final p in res)
                      InkWell(
                        onTap: () => Navigator.pop(context, p['large']),
                        child: Image.network(p['thumb']!, fit: BoxFit.cover, cacheWidth: 300),
                      ),
                  ],
                ),
        ),
      );
}

// ───────────────────────── Design ─────────────────────────
class DesignScreen extends StatefulWidget {
  const DesignScreen({super.key});
  @override
  State<DesignScreen> createState() => _DesignScreenState();
}

class _DesignScreenState extends State<DesignScreen> {
  Deck get d => app.deck;
  void upd(VoidCallback f) {
    setState(f);
    app.save();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(app.t('design'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(
              initialValue: d.title,
              onChanged: (v) {
                d.title = v;
                app.save();
              },
              decoration: InputDecoration(labelText: app.t('deckTitle'), border: const OutlineInputBorder())),
          const SizedBox(height: 12),
          TextFormField(
              initialValue: d.author,
              onChanged: (v) {
                d.author = v;
                app.save();
              },
              decoration: InputDecoration(labelText: app.t('author'), border: const OutlineInputBorder())),
          const SizedBox(height: 20),
          Text(app.t('theme'), style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (d.custom != null)
              ChoiceChip(
                selected: d.themeId == 'custom',
                onSelected: (_) => upd(() => d.themeId = 'custom'),
                avatar: CircleAvatar(backgroundColor: Color(int.parse('FF${d.custom!['accent']}', radix: 16))),
                label: const Text('AI'),
              ),
            for (final th in themes)
              ChoiceChip(
                selected: d.themeId == th.id,
                onSelected: (_) => upd(() => d.themeId = th.id),
                avatar: CircleAvatar(backgroundColor: th.c(th.accent)),
                label: Text(th.name),
              ),
          ]),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: allFonts.contains(d.font) ? d.font : null,
            isExpanded: true,
            decoration: InputDecoration(labelText: app.t('font'), border: const OutlineInputBorder()),
            items: [for (final f in allFonts) DropdownMenuItem(value: f, child: Text(f))],
            selectedItemBuilder: (_) => [for (final f in allFonts) Text(f, style: f == d.font ? previewStyle(f) : null)],
            onChanged: (v) => upd(() => d.font = v!),
          ),
          const SizedBox(height: 4),
          Text(app.t('fontNote'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: DropdownButtonFormField<int>(
                value: titleSizes.contains(d.titleSize) ? d.titleSize : null,
                decoration: InputDecoration(labelText: app.t('titleSize'), border: const OutlineInputBorder()),
                items: [for (final n in titleSizes) DropdownMenuItem(value: n, child: Text('$n'))],
                onChanged: (v) => upd(() => d.titleSize = v!),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<int>(
                value: bodySizes.contains(d.bodySize) ? d.bodySize : null,
                decoration: InputDecoration(labelText: app.t('bodySize'), border: const OutlineInputBorder()),
                items: [for (final n in bodySizes) DropdownMenuItem(value: n, child: Text('$n'))],
                onChanged: (v) => upd(() => d.bodySize = v!),
              ),
            ),
          ]),
          SwitchListTile(title: Text(app.t('rtl')), value: d.rtl, onChanged: (v) => upd(() => d.rtl = v)),
          SwitchListTile(title: Text(app.t('numbers')), value: d.numbers, onChanged: (v) => upd(() => d.numbers = v)),
        ]),
      );
}

// ───────────────────────── Settings ─────────────────────────
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int? progress;

  Future<void> _fonts() async {
    final list = allFonts.where((f) => previewStyle(f) != null).toList();
    for (var i = 0; i < list.length; i++) {
      setState(() => progress = i + 1);
      try {
        await GoogleFonts.pendingFonts([GoogleFonts.getFont(list[i])]);
      } catch (_) {}
    }
    if (mounted) {
      setState(() => progress = null);
      toast(context, app.t('done'));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(app.t('settings'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text(app.t('lang'), style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'fa', label: Text('فارسی')), ButtonSegment(value: 'en', label: Text('English'))],
            selected: {app.lang},
            onSelectionChanged: (v) {
              app.lang = v.first;
              app.deck.rtl = v.first == 'fa';
              app.save();
              setState(() {});
            },
          ),
          const SizedBox(height: 24),
          Text('هوش مصنوعی اصلی', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: app.aiProvider,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'انتخاب سرویس'),
            items: const [
              DropdownMenuItem(value: 'chatgpt', child: Text('ChatGPT  •  OpenAI')),
              DropdownMenuItem(value: 'claude', child: Text('Claude  •  Anthropic')),
              DropdownMenuItem(value: 'gemini', child: Text('Gemini  •  Google')),
              DropdownMenuItem(value: 'deepseek', child: Text('DeepSeek')),
              DropdownMenuItem(value: 'groq', child: Text('Groq')),
            ],
            onChanged: (v) { if (v != null) { app.aiProvider = v; app.save(); setState(() {}); } },
          ),
          const SizedBox(height: 8),
          const Text('کلید هر سرویس را جداگانه وارد کنید. کلیدها در حافظه برنامه روی همین دستگاه ذخیره می‌شوند؛ در این نسخه رمزنگاری اختصاصی ندارند. اگر کلیدی وارد نشود، برنامه از حالت رایگانِ جایگزین استفاده می‌کند.'),
          const SizedBox(height: 12),
          ...[
            ('chatgpt', 'ChatGPT / OpenAI API Key'),
            ('claude', 'Claude / Anthropic API Key'),
            ('gemini', 'Gemini API Key'),
            ('deepseek', 'DeepSeek API Key'),
            ('groq', 'Groq API Key'),
          ].map((entry) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: TextFormField(
              key: ValueKey('key_${entry.$1}'),
              initialValue: app.aiKeys[entry.$1] ?? '',
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              textDirection: TextDirection.ltr,
              onChanged: (v) {
                app.aiKeys[entry.$1] = v.trim();
                if (entry.$1 == 'gemini') app.geminiKey = v.trim();
                app.save();
              },
              decoration: InputDecoration(
                labelText: entry.$2,
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.key_outlined),
                suffixIcon: IconButton(
                  tooltip: 'پاک کردن کلید',
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    app.aiKeys.remove(entry.$1);
                    if (entry.$1 == 'gemini') app.geminiKey = '';
                    app.save();
                    setState(() {});
                  },
                ),
              ),
            ),
          )),
          const SizedBox(height: 12),
          const ProxySection(),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(
            onPressed: progress == null ? _fonts : null,
            icon: const Icon(Icons.download),
            label: Text(progress == null ? app.t('downloadFonts') : '$progress / ${allFonts.length}'),
          ),
        ]),
      );
}

// ───────────────────────── Assistant ─────────────────────────
class ChatMsg {
  final bool user, done;
  final String text;
  ChatMsg(this.user, this.text, {this.done = false});
}

final chat = <ChatMsg>[];

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});
  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final ctl = TextEditingController();
  final scroll = ScrollController();
  final stt = SpeechToText();
  bool busy = false, listening = false;
  String status = '';

  void _down() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  Future<void> _mic() async {
    if (listening) {
      await stt.stop();
      setState(() => listening = false);
      return;
    }
    final ok = await stt.initialize(onStatus: (s) {
      if ((s == 'done' || s == 'notListening') && mounted) setState(() => listening = false);
    });
    if (!ok) {
      if (mounted) toast(context, app.t('micFail'));
      return;
    }
    setState(() => listening = true);
    await stt.listen(
      localeId: app.lang == 'fa' ? 'fa_IR' : 'en_US',
      onResult: (r) => setState(() => ctl.text = r.recognizedWords),
    );
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? ctl.text).trim();
    if (text.isEmpty || busy) return;
    if (listening) await stt.stop();
    ctl.clear();
    setState(() {
      chat.add(ChatMsg(true, text));
      busy = true;
      listening = false;
      status = app.t('thinking');
    });
    _down();
    try {
      final prev = chat.sublist(0, chat.length - 1);
      final hist = [
        for (final m in prev.reversed.take(6).toList().reversed) {'role': m.user ? 'user' : 'assistant', 'content': m.text}
      ];
      final raw = await Ai.ask(hist, Ai.userPrompt(text));
      final j = Ai.parse(raw);
      final reply = (j['reply'] ?? '').toString();
      if (j['deck'] is Map) {
        setState(() => status = app.t('fetchingImages'));
        await Ai.applyDeck(Map<String, dynamic>.from(j['deck']));
        app.save();
        chat.add(ChatMsg(false, reply, done: true));
      } else {
        chat.add(ChatMsg(false, reply));
      }
    } catch (e) {
      chat.add(ChatMsg(false, '${app.t('aiFail')}\n$e'));
    }
    if (mounted) setState(() => busy = false);
    _down();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(app.t('assistant'))),
      body: Column(children: [
        Expanded(
          child: chat.isEmpty
              ? ListView(padding: const EdgeInsets.all(24), children: [
                  const SizedBox(height: 24),
                  Icon(Icons.auto_awesome, size: 48, color: cs.primary),
                  const SizedBox(height: 16),
                  Text(app.t('hello'), textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  for (final k in ['s1', 's2', 's3'])
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ActionChip(label: Text(app.t(k)), onPressed: () => _send(app.t(k))),
                    ),
                ])
              : ListView.builder(
                  controller: scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: chat.length,
                  itemBuilder: (_, i) {
                    final m = chat[i];
                    return Align(
                      alignment: m.user ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: m.user ? cs.primaryContainer : cs.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          SelectableText(m.text),
                          if (m.done) ...[
                            const SizedBox(height: 8),
                            Wrap(spacing: 8, children: [
                              FilledButton.tonal(onPressed: () => tabIndex.value = 0, child: Text(app.t('viewSlides'))),
                              FilledButton(onPressed: () => exportDeck(context), child: Text(app.t('export'))),
                            ]),
                          ],
                        ]),
                      ),
                    );
                  },
                ),
        ),
        if (busy)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(children: [
              const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
              const SizedBox(width: 10),
              Text(status),
            ]),
          ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              IconButton.filledTonal(
                onPressed: busy ? null : _mic,
                icon: Icon(listening ? Icons.stop : Icons.mic),
                color: listening ? Colors.red : null,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: ctl,
                  minLines: 1,
                  maxLines: 4,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(hintText: app.t('typeMsg'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24))), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: busy ? null : _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}


// ───────────────────────── Proxy / V2Ray ─────────────────────────
class ProxySection extends StatefulWidget {
  const ProxySection({super.key});
  @override
  State<ProxySection> createState() => _ProxySectionState();
}

class _ProxySectionState extends State<ProxySection> {
  late final host = TextEditingController(text: app.proxyHost);
  late final port = TextEditingController(text: app.proxyPort);
  late final raw = TextEditingController(text: app.v2rayRaw);
  final sub = TextEditingController();
  bool busy = false;
  String? note;

  List<String> get links => V2.links(raw.text);

  Future<void> _connect() async {
    final l = links;
    if (l.isEmpty) { setState(() => note = 'هیچ کانفیگ معتبری پیدا نشد (vmess / vless / trojan / ss).'); return; }
    setState(() { busy = true; note = null; });
    try {
      app.v2rayIndex = app.v2rayIndex.clamp(0, l.length - 1);
      app.v2rayRaw = raw.text.trim();
      app.save();
      await V2.start(l[app.v2rayIndex]);
      await Future.delayed(const Duration(seconds: 2));
      await Net.prepare();
      final ok = await V2.test();
      note = ok ? 'متصل شد و اینترنت از مسیر V2Ray کار می‌کند ✅' : 'هسته روشن شد اما اینترنت پاسخ نداد؛ کانفیگ دیگری را امتحان کنید.';
    } catch (e) {
      note = 'خطا در اتصال: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _disconnect() async {
    await V2.stop();
    if (mounted) setState(() => note = 'قطع شد.');
  }

  Future<void> _fetchSub() async {
    if (!sub.text.trim().startsWith('http')) return;
    setState(() { busy = true; note = null; });
    try {
      final t = await V2.fetchSubscription(sub.text);
      if (t.isEmpty) {
        note = 'ساب‌اسکریپشن خالی بود یا فرمتش پشتیبانی نمی‌شود.';
      } else {
        raw.text = t;
        app.v2rayRaw = t;
        app.v2rayIndex = 0;
        app.save();
        note = '${V2.links(t).length} کانفیگ دریافت شد.';
      }
    } catch (e) {
      note = 'دریافت ساب‌اسکریپشن ناموفق بود (ممکن است نیاز به اینترنت/پروکسی دیگری باشد).';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final l = links;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Divider(height: 32),
      Text('پروکسی و V2Ray', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      const Text('برای اتصال به سرویس‌های هوش مصنوعی از داخل برنامه؛ فقط ترافیک همین برنامه عبور می‌کند و VPN کل گوشی روشن نمی‌شود.'),
      const SizedBox(height: 12),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'none', label: Text('بدون')),
          ButtonSegment(value: 'manual', label: Text('پروکسی')),
          ButtonSegment(value: 'v2ray', label: Text('V2Ray')),
        ],
        selected: {app.proxyMode},
        onSelectionChanged: (v) { app.proxyMode = v.first; app.save(); Net.prepare(); setState(() {}); },
      ),
      const SizedBox(height: 12),
      if (app.proxyMode == 'manual') ...[
        SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'http', label: Text('HTTP')), ButtonSegment(value: 'socks5', label: Text('SOCKS5'))],
          selected: {app.proxyType},
          onSelectionChanged: (v) { app.proxyType = v.first; app.save(); Net.prepare(); setState(() {}); },
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: host, textDirection: TextDirection.ltr, autocorrect: false,
              decoration: const InputDecoration(labelText: 'آدرس (مثلاً 127.0.0.1)', border: OutlineInputBorder()),
              onChanged: (v) { app.proxyHost = v.trim(); app.save(); Net.prepare(); },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextField(
              controller: port, keyboardType: TextInputType.number, textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'پورت', border: OutlineInputBorder()),
              onChanged: (v) { app.proxyPort = v.trim(); app.save(); },
            ),
          ),
        ]),
        const SizedBox(height: 8),
        const Text('اگر برنامه V2RayNG/Hiddify روی همین گوشی در حال اجراست، معمولاً آدرس 127.0.0.1 و پورت SOCKS (مثلاً 10808) یا HTTP (مثلاً 10809) را بزنید.', style: TextStyle(fontSize: 12)),
      ],
      if (app.proxyMode == 'v2ray') ...[
        TextField(
          controller: sub, textDirection: TextDirection.ltr, autocorrect: false,
          decoration: InputDecoration(
            labelText: 'لینک ساب‌اسکریپشن (اختیاری)', border: const OutlineInputBorder(),
            suffixIcon: IconButton(icon: const Icon(Icons.cloud_download_outlined), onPressed: busy ? null : _fetchSub),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: raw, minLines: 3, maxLines: 6, textDirection: TextDirection.ltr, autocorrect: false,
          decoration: const InputDecoration(
            labelText: 'کانفیگ‌ها: vmess:// vless:// trojan:// ss:// (هر خط یکی)',
            border: OutlineInputBorder(), alignLabelWithHint: true),
          onChanged: (v) { app.v2rayRaw = v.trim(); app.save(); setState(() {}); },
        ),
        if (l.length > 1) ...[
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: app.v2rayIndex.clamp(0, l.length - 1),
            isExpanded: true,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'کانفیگ انتخابی'),
            items: [for (var i = 0; i < l.length; i++) DropdownMenuItem(value: i, child: Text(V2.remark(l[i]), overflow: TextOverflow.ellipsis))],
            onChanged: (v) { if (v != null) { app.v2rayIndex = v; app.save(); setState(() {}); } },
          ),
        ],
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('اتصال خودکار هنگام باز شدن برنامه'),
          value: app.v2rayAuto,
          onChanged: (v) { app.v2rayAuto = v; app.save(); setState(() {}); },
        ),
        ValueListenableBuilder<String>(
          valueListenable: V2.status,
          builder: (_, st, __) => Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: busy || st == 'CONNECTED' ? null : _connect,
                icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.power_settings_new),
                label: Text(st == 'CONNECTED' ? 'متصل' : 'اتصال'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: st == 'CONNECTED' ? _disconnect : null,
                icon: const Icon(Icons.stop_circle_outlined),
                label: const Text('قطع'),
              ),
            ),
          ]),
        ),
      ],
      if (note != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(note!)),
    ]);
  }
}
