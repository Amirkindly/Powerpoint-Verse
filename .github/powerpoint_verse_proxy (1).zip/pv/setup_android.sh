#!/usr/bin/env bash
# Run once (locally or in CI) from project root
set -e
flutter create --org com.powerpointverse --project-name powerpoint_verse --platforms android .
rm -rf test
M=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="PowerPoint Verse"/' $M
grep -q 'permission.INTERNET' $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <queries><intent><action android:name="android.speech.RecognitionService"/></intent></queries>\n    <application#' $M
# V2Ray core needs minSdk 23 and extractNativeLibs
for G in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$G" ] && sed -i 's/minSdkVersion flutter.minSdkVersion/minSdkVersion 23/; s/minSdk = flutter.minSdkVersion/minSdk = 23/' "$G"
done
# extractNativeLibs داخل Manifest مجاز نیست؛ از useLegacyPackaging در gradle استفاده می‌کنیم
sed -i 's# android:extractNativeLibs="[a-z]*"##' $M
if [ -f android/app/build.gradle.kts ]; then
  grep -q useLegacyPackaging android/app/build.gradle.kts || sed -i '0,/^android {/s//android {\n    packaging { jniLibs { useLegacyPackaging = true } }/' android/app/build.gradle.kts
elif [ -f android/app/build.gradle ]; then
  grep -q useLegacyPackaging android/app/build.gradle || sed -i '0,/^android {/s//android {\n    packagingOptions { jniLibs { useLegacyPackaging = true } }/' android/app/build.gradle
fi
mkdir -p assets/web
curl -L -o assets/web/pptxgen.bundle.js https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js || true
flutter pub get
