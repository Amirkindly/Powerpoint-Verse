import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum SlideType { cover, section, bullets, image, chart, table, text, thanks }

IconData typeIcon(SlideType t) => const {
      SlideType.cover: Icons.slideshow,
      SlideType.section: Icons.bookmark_outline,
      SlideType.bullets: Icons.format_list_bulleted,
      SlideType.image: Icons.image_outlined,
      SlideType.chart: Icons.bar_chart,
      SlideType.table: Icons.table_chart_outlined,
      SlideType.text: Icons.notes,
      SlideType.thanks: Icons.favorite_border,
    }[t]!;

class SlideModel {
  String id;
  SlideType type;
  String title, subtitle, body, chartType, chartData, seriesName, tableData;
  String? image, bg;
  String imageQuery, bgQuery;

  SlideModel({
    String? id,
    required this.type,
    this.title = '',
    this.subtitle = '',
    this.body = '',
    this.image,
    this.bg,
    this.imageQuery = '',
    this.bgQuery = '',
    this.chartType = 'bar',
    this.chartData = '',
    this.seriesName = '',
    this.tableData = '',
  }) : id = id ?? DateTime.now().microsecondsSinceEpoch.toString();

  factory SlideModel.create(SlideType t) {
    switch (t) {
      case SlideType.cover:
        return SlideModel(type: t, title: 'Presentation Title', subtitle: 'Subtitle');
      case SlideType.section:
        return SlideModel(type: t, title: 'Section', subtitle: '');
      case SlideType.bullets:
        return SlideModel(type: t, title: 'Title', body: 'Point one\nPoint two\nPoint three');
      case SlideType.image:
        return SlideModel(type: t, title: 'Image');
      case SlideType.chart:
        return SlideModel(type: t, title: 'Chart', seriesName: 'Series', chartData: 'Q1,10\nQ2,25\nQ3,18\nQ4,32');
      case SlideType.table:
        return SlideModel(type: t, title: 'Table', tableData: 'Name,Value\nA,1\nB,2');
      case SlideType.text:
        return SlideModel(type: t, title: 'Title', body: 'Write your text here...');
      case SlideType.thanks:
        return SlideModel(type: t, title: 'Thank you', subtitle: '');
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id, 'type': type.name, 'title': title, 'subtitle': subtitle, 'body': body,
        'image': image, 'bg': bg, 'imageQuery': imageQuery, 'bgQuery': bgQuery, 'chartType': chartType, 'chartData': chartData,
        'seriesName': seriesName, 'tableData': tableData,
      };

  factory SlideModel.fromJson(Map<String, dynamic> j) => SlideModel(
        id: j['id'],
        type: SlideType.values.firstWhere((e) => e.name == j['type'], orElse: () => SlideType.text),
        title: j['title'] ?? '', subtitle: j['subtitle'] ?? '', body: j['body'] ?? '',
        image: j['image'], bg: j['bg'], imageQuery: j['imageQuery'] ?? '', bgQuery: j['bgQuery'] ?? '', chartType: j['chartType'] ?? 'bar', chartData: j['chartData'] ?? '',
        seriesName: j['seriesName'] ?? '', tableData: j['tableData'] ?? '',
      );
}

class AppTheme {
  final String id, name, bg, title, text, accent, accent2;
  const AppTheme(this.id, this.name, this.bg, this.title, this.text, this.accent, this.accent2);
  Color c(String h) => Color(int.parse('FF$h', radix: 16));
}

const themes = [
  AppTheme('ocean', 'Ocean', 'FFFFFF', '0B3C5D', '333333', '1D70B8', 'F5A623'),
  AppTheme('midnight', 'Midnight', '12121C', 'FFFFFF', 'D0D0E0', '7C5CFF', '00D1B2'),
  AppTheme('sunset', 'Sunset', 'FFF8F0', '8A2B0B', '4A3B32', 'E8590C', 'F59F00'),
  AppTheme('forest', 'Forest', 'F4FAF4', '1B4332', '2D3A32', '2D6A4F', '95D5B2'),
  AppTheme('rose', 'Rose', 'FFF5F7', '7A1F3D', '3E2A33', 'D6336C', 'FCC2D7'),
  AppTheme('mono', 'Mono', 'FFFFFF', '000000', '333333', '212529', 'ADB5BD'),
  AppTheme('gold', 'Gold', '1A1A1A', 'F5D76E', 'E8E8E8', 'C9A227', '8E6F1A'),
  AppTheme('royal', 'Royal', 'F0F4FF', '1E2A78', '2B2B3A', '3F51B5', 'FF9800'),
];

const persianFonts = [
  'Vazirmatn', 'Noto Naskh Arabic', 'Noto Sans Arabic', 'Cairo', 'Tajawal', 'Almarai', 'Amiri',
  'Lalezar', 'Markazi Text', 'Lateef', 'Scheherazade New', 'Reem Kufi', 'Changa', 'El Messiri',
  'Harmattan', 'Mirza', 'Katibeh', 'Aref Ruqaa', 'Lemonada', 'Rakkas',
  'B Nazanin', 'B Titr', 'B Koodak', 'B Mitra', 'B Yekan', 'IRANSans', 'Sahel', 'Shabnam', 'Samim', 'Tanha',
];
const englishFonts = [
  'Calibri', 'Arial', 'Tahoma', 'Times New Roman', 'Verdana', 'Georgia', 'Cambria', 'Segoe UI',
  'Trebuchet MS', 'Century Gothic', 'Garamond', 'Impact', 'Courier New', 'Consolas',
  'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins', 'Raleway', 'Oswald', 'Nunito',
  'Playfair Display', 'Merriweather', 'Inter', 'Rubik', 'Lora', 'Bebas Neue', 'Pacifico',
];
const allFonts = [...persianFonts, ...englishFonts];
const _nonGoogle = {
  'B Nazanin', 'B Titr', 'B Koodak', 'B Mitra', 'B Yekan', 'IRANSans', 'Sahel', 'Shabnam', 'Samim', 'Tanha',
  'Calibri', 'Arial', 'Tahoma', 'Times New Roman', 'Verdana', 'Georgia', 'Cambria', 'Segoe UI',
  'Trebuchet MS', 'Century Gothic', 'Garamond', 'Impact', 'Courier New', 'Consolas',
};
const titleSizes = [20, 24, 28, 32, 36, 40, 44, 48, 54, 60];
const bodySizes = [12, 14, 16, 18, 20, 22, 24, 28, 32];

/// Preview style (downloads the font from Google Fonts automatically when available).
TextStyle? previewStyle(String f) {
  if (_nonGoogle.contains(f)) return null;
  try {
    return GoogleFonts.getFont(f);
  } catch (_) {
    return null;
  }
}

String _latin(String s) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  var o = s.replaceAll('٫', '.').replaceAll('٬', '');
  for (var i = 0; i < 10; i++) {
    o = o.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return o;
}

List<String> _lines(String x) => x.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

class Deck {
  String title, author, themeId, font;
  int titleSize, bodySize;
  bool rtl, numbers;
  Map<String, String>? custom;
  List<SlideModel> slides;

  Deck({
    this.title = 'My Presentation', this.author = '', this.themeId = 'ocean', this.font = 'Tahoma',
    this.titleSize = 36, this.bodySize = 20, this.rtl = false, this.numbers = true, this.custom, List<SlideModel>? slides,
  }) : slides = slides ?? [SlideModel.create(SlideType.cover), SlideModel.create(SlideType.thanks)];

  AppTheme get theme {
    final c = custom;
    if (themeId == 'custom' && c != null) {
      return AppTheme('custom', 'AI', c['bg']!, c['title']!, c['text']!, c['accent']!, c['accent2']!);
    }
    return themes.firstWhere((t) => t.id == themeId, orElse: () => themes.first);
  }

  Map<String, dynamic> toJson() => {
        'title': title, 'author': author, 'themeId': themeId, 'font': font,
        'titleSize': titleSize, 'bodySize': bodySize, 'rtl': rtl, 'numbers': numbers, 'custom': custom,
        'slides': slides.map((s) => s.toJson()).toList(),
      };

  factory Deck.fromJson(Map<String, dynamic> j) => Deck(
        title: j['title'] ?? '', author: j['author'] ?? '', themeId: j['themeId'] ?? 'ocean',
        font: j['font'] ?? 'Tahoma', titleSize: j['titleSize'] ?? 36, bodySize: j['bodySize'] ?? 20,
        rtl: j['rtl'] ?? false, numbers: j['numbers'] ?? true,
        custom: j['custom'] == null ? null : Map<String, String>.from(j['custom']),
        slides: (j['slides'] as List).map((e) => SlideModel.fromJson(Map<String, dynamic>.from(e))).toList(),
      );

  Map<String, dynamic> toPptJson() {
    final th = theme;
    return {
      'title': title, 'author': author, 'rtl': rtl, 'font': font,
      'titleSize': titleSize, 'bodySize': bodySize, 'numbers': numbers,
      'theme': {'bg': th.bg, 'title': th.title, 'text': th.text, 'accent': th.accent, 'accent2': th.accent2},
      'slides': slides.map(_slide).toList(),
    };
  }

  Map<String, dynamic> _slide(SlideModel s) {
    final labels = <String>[];
    final values = <double>[];
    if (s.type == SlideType.chart) {
      for (final l in _lines(s.chartData)) {
        final line = l.replaceAll('،', ',');
        final i = line.lastIndexOf(',');
        if (i < 0) continue;
        final v = double.tryParse(_latin(line.substring(i + 1).trim()));
        if (v == null) continue;
        labels.add(line.substring(0, i).trim());
        values.add(v);
      }
    }
    var rows = <List<String>>[];
    if (s.type == SlideType.table) {
      rows = _lines(s.tableData).map((l) => l.replaceAll('،', ',').split(',').map((e) => e.trim()).toList()).toList();
      final n = rows.fold<int>(0, (m, r) => r.length > m ? r.length : m);
      for (final r in rows) {
        while (r.length < n) {
          r.add('');
        }
      }
    }
    return {
      'type': s.type.name, 'title': s.title, 'subtitle': s.subtitle,
      'bullets': _lines(s.body), 'image': s.image, 'bg': s.bg,
      'chartType': s.chartType, 'labels': labels, 'values': values, 'series': s.seriesName, 'rows': rows,
    };
  }
}

class AppState extends ChangeNotifier {
  Deck deck = Deck();
  String lang = 'fa';
  String geminiKey = '';
  SharedPreferences? _p;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    lang = _p!.getString('lang') ?? 'fa';
    geminiKey = _p!.getString('gemini') ?? '';
    final raw = _p!.getString('deck');
    if (raw != null) {
      try {
        deck = Deck.fromJson(jsonDecode(raw));
      } catch (_) {}
    } else {
      deck.rtl = lang == 'fa';
    }
  }

  void save() {
    _p?.setString('deck', jsonEncode(deck.toJson()));
    _p?.setString('lang', lang);
    _p?.setString('gemini', geminiKey);
    notifyListeners();
  }

  String t(String k) => _s[lang]?[k] ?? _s['en']![k] ?? k;
}

final app = AppState();

const _s = {
  'fa': {
    'madeBy': 'ساخته‌شده توسط', 'author_name': 'امیررضا بهادری',
    'assistant': 'دستیار', 'slidesTab': 'اسلایدها', 'typeMsg': 'موضوع ارائه را بگویید...',
    'thinking': 'در حال طراحی ارائه...', 'fetchingImages': 'در حال پیدا کردن تصاویر...',
    'aiFail': 'ارتباط با هوش مصنوعی برقرار نشد. دوباره تلاش کنید.', 'viewSlides': 'مشاهده اسلایدها',
    'hello': 'موضوع، تعداد اسلاید، رنگ و حال‌وهوای ارائه را بگویید تا برایتان بسازم. بعداً هم می‌توانید بگویید چه چیزی را تغییر دهم.',
    's1': 'یک ارائه ۷ اسلایدی درباره انرژی خورشیدی با رنگ سبز و آبی',
    's2': 'ارائه‌ای درباره تاریخ ایران باستان برای دانشجوها',
    's3': 'پیشنهاد کسب‌وکار یک کافه جدید، حرفه‌ای و گرم',
    'geminiKey': 'کلید Gemini (اختیاری، برای کیفیت بهتر)', 'bgImage': 'تصویر پس‌زمینه', 'remove': 'حذف',
    'micFail': 'میکروفون در دسترس نیست',
    'design': 'طراحی', 'settings': 'تنظیمات', 'export': 'ساخت پاورپوینت', 'add': 'افزودن اسلاید',
    'empty': 'اسلایدی نیست. دکمه + را بزنید.', 'cover': 'کاور', 'section': 'بخش', 'bullets': 'لیست نکات',
    'image': 'تصویر', 'chart': 'نمودار', 'table': 'جدول', 'text': 'متن', 'thanks': 'پایان / تشکر',
    'title': 'عنوان', 'subtitle': 'زیرعنوان', 'author': 'نویسنده', 'deckTitle': 'عنوان ارائه',
    'theme': 'قالب رنگی', 'font': 'فونت', 'titleSize': 'اندازه عنوان', 'bodySize': 'اندازه متن',
    'rtl': 'راست‌به‌چپ (فارسی)', 'numbers': 'شماره اسلاید', 'bodyHint': 'هر خط یک مورد', 'caption': 'توضیح تصویر',
    'gallery': 'گالری', 'url': 'لینک', 'search': 'جستجوی آنلاین (بدون کلید)',
    'chartType': 'نوع نمودار', 'series': 'نام سری', 'chartHint': 'هر خط: برچسب,عدد   مثال: فروردین,120',
    'tableHint': 'هر خط یک ردیف، ستون‌ها با کاما. خط اول سرستون است.', 'lang': 'زبان', 'exporting': 'در حال ساخت فایل...',
    'error': 'خطا', 'downloadFonts': 'دانلود فونت‌ها برای پیش‌نمایش',
    'done': 'انجام شد', 'imageUrl': 'آدرس تصویر', 'ok': 'تأیید', 'cancel': 'لغو', 'bar': 'ستونی', 'line': 'خطی',
    'pie': 'دایره‌ای', 'doughnut': 'حلقه‌ای', 'area': 'ناحیه‌ای', 'query': 'جستجو...', 'fontNote':
        'فونت داخل فایل ذخیره نمی‌شود؛ برای نمایش درست، فونت باید روی دستگاه گیرنده نصب باشد (Tahoma امن‌ترین است).',
  },
  'en': {
    'madeBy': 'Created by', 'author_name': 'Amirreza Bahadori',
    'assistant': 'Assistant', 'slidesTab': 'Slides', 'typeMsg': 'Describe your presentation...',
    'thinking': 'Designing your presentation...', 'fetchingImages': 'Finding images...',
    'aiFail': 'Could not reach the AI. Please try again.', 'viewSlides': 'View slides',
    'hello': 'Tell me the topic, slide count, colors and mood and I will build it. You can ask for changes afterwards too.',
    's1': 'A 7-slide presentation about solar energy in green and blue',
    's2': 'A presentation on ancient Rome for students',
    's3': 'A business pitch for a new warm, professional cafe',
    'geminiKey': 'Gemini key (optional, better quality)', 'bgImage': 'Background image', 'remove': 'Remove',
    'micFail': 'Microphone not available',
    'design': 'Design', 'settings': 'Settings', 'export': 'Create PPTX', 'add': 'Add slide',
    'empty': 'No slides. Tap + to add one.', 'cover': 'Cover', 'section': 'Section', 'bullets': 'Bullet list',
    'image': 'Image', 'chart': 'Chart', 'table': 'Table', 'text': 'Text', 'thanks': 'Closing / Thanks',
    'title': 'Title', 'subtitle': 'Subtitle', 'author': 'Author', 'deckTitle': 'Presentation title',
    'theme': 'Color theme', 'font': 'Font', 'titleSize': 'Title size', 'bodySize': 'Body size',
    'rtl': 'Right-to-left', 'numbers': 'Slide numbers', 'bodyHint': 'One item per line', 'caption': 'Image caption',
    'gallery': 'Gallery', 'url': 'URL', 'search': 'Search online',
    'chartType': 'Chart type', 'series': 'Series name', 'chartHint': 'One per line: label,value   e.g. Jan,120',
    'tableHint': 'One row per line, columns separated by commas. First line is the header.', 'lang': 'Language',
    'exporting': 'Building file...', 'error': 'Error',
    'downloadFonts': 'Download fonts for preview', 'done': 'Done', 'imageUrl': 'Image URL', 'ok': 'OK',
    'cancel': 'Cancel', 'bar': 'Bar', 'line': 'Line', 'pie': 'Pie', 'doughnut': 'Doughnut', 'area': 'Area',
    'query': 'Search...', 'fontNote':
        'Fonts are not embedded in the file; the viewing device must have the font installed (Tahoma is the safest).',
  },
};
